// The context provider interface (0014). A provider decides which code a worker sees
// and returns items: data with a structured reason, never prompt prose. The engine renders them
// (DIPO-47). Output is deterministic for the same inputs.

/** Project size class from the `git ls-files` count (0014). */
export type SizeClass = "S" | "M" | "L" | "XL";

/** What a provider reads: one checkout (a story worktree, or `_base`). */
export interface Workspace {
  /** Absolute path of the work tree. */
  readonly root: string;
  /** The commit `HEAD` points at. */
  headSha(): Promise<string>;
  /** `git ls-files`: tracked repo-relative POSIX paths, sorted. */
  trackedFiles(): Promise<readonly string[]>;
  /** Tracked plus untracked, not ignored, repo-relative paths, sorted. */
  files(): Promise<readonly string[]>;
  /**
   * The bytes of a repo-relative file, undefined when it is missing or a directory, or a
   * refusal when the workspace will not read it (a link, a hard link, a secret, a path that
   * leaves the work tree).
   */
  readFile(path: string): Promise<Uint8Array | FileRefusal | undefined>;
  /**
   * The files under `dir` (`""` is the root) that have a commit reachable from `sha`, ordered by
   * the commit that last changed them there, newest first, files of one commit in name order.
   * Files with no such commit are left out. Optional: without it the files are in name order.
   */
  filesByLastCommit?(sha: string, dir: string): Promise<readonly string[]>;
}

/** Why a workspace refused to read a file. */
export interface FileRefusal {
  readonly refused: string;
}

export type ProviderState = "ready" | "stale" | "missing" | "error";

export interface ProviderStatus {
  readonly state: ProviderState;
  /** Why the provider is not ready; empty when it is. */
  readonly reasons: readonly string[];
}

export interface ContextRequest {
  /** F1, the Backlog.md id. */
  readonly storyId: string;
  /** F3, the text of the `Story:` line. */
  readonly storyLine: string;
  /** F4, in Backlog.md order. */
  readonly criteria: readonly string[];
  /** F8: repo-relative paths; a trailing `/` marks a directory. */
  readonly scope: readonly string[];
  /** F9: repo-relative paths or URLs the worker reads but does not write. */
  readonly inputs: readonly string[];
  readonly baseSha: string;
  readonly headSha: string;
  readonly sizeClass: SizeClass;
  /** The `inputs` section budget in characters (0014). */
  readonly inputsBudget: number;
}

/**
 * `text` holds the file (or its head); `binary` and `unreadable` files have empty `text`. A
 * `secret` file (a 0008 secret path such as `.env*`) is listed only: never read, empty `text`. A
 * `refused` file is listed only because the workspace would not read it; the reason carries why.
 */
export type FileContent = "text" | "binary" | "unreadable" | "secret" | "refused";

/** Why an item is in the pack. */
export type ContextReason =
  /** A scope file, in full or as its head with a truncation marker. */
  | {
      readonly kind: "scope-file";
      readonly scope: string;
      readonly content: FileContent;
      readonly truncated: boolean;
      /** Why the workspace would not read it; set only when `content` is `refused`. */
      readonly refusal?: string;
    }
  /**
   * A scope directory: `text` lists the `shown` files changed most recently on the base sha, one
   * path per line; `total` is the number of files under it.
   */
  | {
      readonly kind: "scope-dir";
      readonly scope: string;
      readonly shown: number;
      readonly total: number;
    }
  /** A scope path that does not exist yet: `text` summarises `parent` like a scope directory. */
  | {
      readonly kind: "scope-new";
      readonly scope: string;
      readonly parent: string;
      readonly shown: number;
      readonly total: number;
    }
  /** A test next to a scope file by name; listed, never inlined (`text` is empty). */
  | { readonly kind: "test"; readonly of: string }
  /** An input file, pre-fetched within the inputs budget. */
  | {
      readonly kind: "input-file";
      readonly input: string;
      readonly content: FileContent;
      readonly truncated: boolean;
      /** Why the workspace would not read it; set only when `content` is `refused`. */
      readonly refusal?: string;
    }
  /** An input whose content did not fit the inputs budget: listed only. */
  | { readonly kind: "input-listed"; readonly input: string }
  /** An input URL: listed only, never fetched. */
  | { readonly kind: "input-url"; readonly input: string }
  /** An input path that does not exist. */
  | { readonly kind: "input-missing"; readonly input: string };

export interface ContextItem {
  /** Repo-relative path, or URL for URL inputs. */
  readonly path: string;
  /** 1-based inclusive line range when `text` is part of a file. */
  readonly range?: { readonly from: number; readonly to: number };
  readonly text: string;
  readonly reason: ContextReason;
}

export interface ContextProvenance {
  readonly provider: string;
  readonly version: string;
  readonly indexState: ProviderState;
  readonly staleFiles: readonly string[];
  /** Why a backend was skipped; empty when there are none. */
  readonly notes: readonly string[];
}

/** The `inputs` section (0014): the full path list plus pre-fetched content. */
export interface InputsPart {
  /** Every declared input, in request order; never cut. */
  readonly paths: readonly string[];
  readonly items: readonly ContextItem[];
  readonly usedChars: number;
  readonly truncated: boolean;
}

export interface ContextPack {
  /** The `context` section items, in a deterministic order. */
  readonly items: readonly ContextItem[];
  /** Characters of the `context` items (path plus text of each). */
  readonly usedChars: number;
  /** True when any item was cut or dropped for the budget. */
  readonly truncated: boolean;
  readonly provenance: ContextProvenance;
  /** Filled by the default provider; a backend leaves it empty. */
  readonly inputs: InputsPart;
  /** Git blob ids of the scope and input files whose content was read, by path. */
  readonly blobIds: Readonly<Record<string, string>>;
}

export interface ContextProvider {
  /** `default`, `codegraph`. */
  readonly id: string;
  status(ws: Workspace): Promise<ProviderStatus>;
  /** Index or sync; runs before the worker, outside its budget. */
  prepare?(ws: Workspace): Promise<void>;
  gather(req: ContextRequest, budget: number): Promise<ContextPack>;
}
