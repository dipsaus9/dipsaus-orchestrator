// The shared vocabulary of worker outcomes: the intent tags, notices and the ports between run
// control and the outcome units. `outcomes.ts` re-exports all of it.

import {
  type Clock,
  KNOWN_PARK_REASONS,
  type OfficeId,
  type ParkReason,
  type RunId,
  type StoryKey,
  type WorkRef,
} from "@dipsaus-orchestrator/contract";
import { z } from "zod";

import type { OfficeHandle } from "../db/office";
import type { IngestedExit } from "../ingest/ingestor";
import { FEEDBACK_TEMPLATES, renderTemplate } from "../prompts/templates";
import type { WorkerPort } from "../workers/port";
import type { Caps, HostOp, ReviewReport, SteerOp, TurnProblem } from "../workers/types";
import type { ClaimRecord } from "../worktree/records";

import type { RunEnding, RunSteering } from "./control-types";
import type { IntentKind } from "../records/intents";
import { type ParkOutcome, type UnparkWriter } from "./park";
import type { ParkStore } from "../records/park-state";
import type { StoredRun } from "../records/run-records";
import type { NextSession } from "./resume";
import type {
  AdapterPause,
  LaunchCheckFailure,
  PlanLimitPause,
  StartsPausedState,
} from "./starts-paused";
import type { StoryGit } from "./story-git";

/** The tags DIPO-51 stores at the start of an intent's detail. */
export const INTENT_TAGS = {
  contextFull: "new-session:context-full",
  error: "new-session:error",
  initRejected: "init-rejected",
  startFailed: "start-failed",
  /** A park intent of a blocked report: the worker's question follows (DIPO-430). */
  question: "worker-question",
  /**
   * The start of a park intent's tag, which ends with the park's reason; the park's facts follow
   * as JSON (`parkIntentDetail`, DIPO-433).
   */
  parkReason: "park-reason:",
} as const;

/** `engine.notice` codes of worker outcomes. */
export const OUTCOME_NOTICES = {
  initRejected: "run.initRejected",
  modelSwitched: "run.modelSwitched",
  startFailed: "run.startFailed",
  feedbackNotSent: "run.feedbackNotSent",
} as const;

/** `agents.end_reason` of an agent whose host died without an exit file (DIPO-57). */
export const HOST_LOST_END = "host-lost";

/** Why a run lost its host, for the park and the resume (0005, 0008). */
export const HOST_LOST_WHY = "the worker host died while the daemon was down";

/** Milliseconds from closing stdin to SIGTERM before a new session (0008). */
export const NEW_SESSION_SIGTERM_AFTER_MS = 10_000;
/** Milliseconds to SIGKILL after a rejected init. */
export const INIT_REJECTED_SIGKILL_AFTER_MS = 30_000;

/**
 * The act of a start the adapter refused at its first line (`startRefused`, DIPO-108): stop the
 * worker at once, as for a rejected init, but as a `start-failed` stop, so its exit holds the
 * adapter and releases the claim (story Ready) instead of parking.
 */
export function startRefusedAct(reason: string): RunAct {
  return {
    intent: "stop",
    detail: `${INTENT_TAGS.startFailed} ${reason}`,
    ops: [
      { closeStdin: true },
      { signal: "SIGTERM" },
      { signal: "SIGKILL", afterMs: INIT_REJECTED_SIGKILL_AFTER_MS },
    ],
  };
}

/** The office load step that decides exits a restart left undecided (maintainer decision Q6). */
export const REDISPATCH_STEP = "run-outcomes/redispatch";

/**
 * The real `RunOutcomesDeps.holdsWork`: the story holds work when its branch moved past the claim
 * commit, or is gone (0008). Its delivered parts are commits on the branch; a story has no
 * worktree.
 */
export function storyHoldsWork(
  story: Pick<StoryGit, "tip">,
): NonNullable<RunOutcomesDeps["holdsWork"]> {
  return async (office, run, claim) => {
    if (run.branch === null || claim === null) return false;
    return (await story.tip(office, run.branch)) !== (claim.claimSha ?? claim.startSha);
  };
}

/** The tag of an intent's detail: its first word. */
export function intentTag(detail: string): string {
  const space = detail.indexOf(" ");
  return space === -1 ? detail : detail.slice(0, space);
}

/** The detail after an intent's tag. */
export function intentRest(detail: string): string {
  const space = detail.indexOf(" ");
  return space === -1 ? "" : detail.slice(space + 1);
}

/**
 * What a park intent keeps of its park (DIPO-433), so a restart before the park was written parks
 * with the same reason and facts.
 */
export interface IntentPark {
  readonly reason: ParkReason;
  readonly detail: string;
  readonly capStep?: string;
  readonly question?: string;
  readonly resumeOnLift?: boolean;
}

const IntentParkReason = z.enum(KNOWN_PARK_REASONS);
const IntentParkFacts = z.strictObject({
  detail: z.string(),
  capStep: z.string().optional(),
  question: z.string().optional(),
  resumeOnLift: z.literal(true).optional(),
});

/** The detail of a park intent: `park-reason:<reason>`, then the park's facts as JSON. */
export function parkIntentDetail(park: IntentPark): string {
  const facts = {
    detail: park.detail,
    ...(park.capStep === undefined ? {} : { capStep: park.capStep }),
    ...(park.question === undefined ? {} : { question: park.question }),
    ...(park.resumeOnLift === true ? { resumeOnLift: true } : {}),
  };
  return `${INTENT_TAGS.parkReason}${park.reason} ${JSON.stringify(facts)}`;
}

/**
 * The park a park intent's detail keeps (`parkIntentDetail`); null for any other detail, one an
 * older dipo wrote, or one whose reason or facts do not parse.
 */
export function intentPark(detail: string): IntentPark | null {
  const tag = intentTag(detail);
  if (!tag.startsWith(INTENT_TAGS.parkReason)) return null;
  const reason = IntentParkReason.safeParse(tag.slice(INTENT_TAGS.parkReason.length));
  if (!reason.success) return null;
  let raw: unknown;
  try {
    raw = JSON.parse(intentRest(detail));
  } catch {
    return null;
  }
  const facts = IntentParkFacts.safeParse(raw);
  if (!facts.success) return null;
  const { detail: parkDetail, capStep, question, resumeOnLift } = facts.data;
  return {
    reason: reason.data,
    detail: parkDetail,
    ...(capStep === undefined ? {} : { capStep }),
    ...(question === undefined ? {} : { question }),
    ...(resumeOnLift === true ? { resumeOnLift } : {}),
  };
}

/** A tracked run as run control hands it over. */
export interface RunView {
  readonly office: OfficeId;
  readonly runId: RunId;
  readonly work: WorkRef;
  readonly caps: Caps;
  /** When the run's first worker started, on the engine clock. */
  readonly startedAt: number;
}

/** An op stored as an intent and sent without a park. */
export interface RunAct {
  readonly intent: IntentKind;
  readonly detail: string;
  readonly ops: readonly HostOp[];
  /** A turn problem's act: when its intent cannot be stored, the next cap tick tries it again (DIPO-123). */
  readonly retryAtTick?: boolean;
}

/** What worker outcomes ask of run control. */
export interface RunEnder {
  /** True while the run is tracked and nothing was decided for it. */
  live(runId: string): boolean;
  /** True while the run is tracked, decided or not (DIPO-57); its exit is decided there. */
  isTracked?(runId: string): boolean;
  /** The first decision on a tracked run, parking it; false when one was made already. */
  begin(runId: string, ending: RunEnding): boolean;
  /** The first decision on a tracked run without a park; false when one was made already. */
  act(runId: string, act: RunAct): boolean;
  /** Parks a run whose worker exited. */
  park(
    office: OfficeHandle,
    run: StoredRun,
    work: WorkRef | undefined,
    ending: RunEnding,
  ): Promise<ParkOutcome>;
}

/** A worker's exit as run control hands it over. */
export interface ExitContext {
  readonly view: RunView;
  readonly agent: string;
  /** The after-turn work of the run's turns before the exit. */
  readonly turns: Promise<void>;
  /** A decision under way, or null. */
  readonly ending: Promise<unknown> | null;
  readonly end: IngestedExit;
}

/** A rejected plan limit as run control hands it over. */
export interface PlanLimitHit {
  readonly credits: boolean;
  readonly resetsAt?: string;
  /** The limit is an HTTP 429, which dipo's model proxy sends at a run's token cap too (DIPO-484). */
  readonly http429?: true;
}

/** The office's starts paused as worker outcomes and the review rounds tell it of a plan limit. */
export interface PlanLimitPauses {
  pausePlanLimit(office: OfficeId, pause: PlanLimitPause): void;
}

/**
 * The office's starts paused as worker outcomes use it (0020): a plan limit pauses it, a run's
 * next session asks it first, and a load that parked runs a plan limit held resumes them.
 */
export interface StartsPausedPort extends PlanLimitPauses {
  state(office: OfficeId): StartsPausedState | null;
  resumeLifted(office: OfficeId): void;
}

/**
 * The park of a session that met a plan limit (0020): `worker-failed` with the limit's detail,
 * resumed by itself when the office's starts paused lifts.
 */
export function planLimitEnding(pause: PlanLimitPause, ops: readonly HostOp[]): RunEnding {
  return {
    intent: "park",
    ops,
    reason: "worker-failed",
    detail: pause.detail,
    resumeOnLift: true,
  };
}

/** What run control calls. */
export interface RunOutcomesPort {
  onTurnProblem(view: RunView, problem: TurnProblem): Promise<void>;
  onPlanLimit(view: RunView, limit: PlanLimitHit): void;
  onModelSwitched(view: RunView, model: string): void;
  /** A turn arrived: an open report feedback is answered. */
  answered(view: RunView): void;
  /**
   * A reviewer session's turn carried a report valid against the review schema (0002),
   * after the backstop let the turn continue (DIPO-219).
   */
  onReview?(view: RunView, report: ReviewReport): Promise<void>;
  onExit(exit: ExitContext): Promise<void>;
}

/**
 * The ending of a rejected init (0008); `cause` is the session's, the
 * reviewer's `review` for a reviewer session (0002).
 */
export function initRejectedEnding(story: string, reason: string): RunEnding {
  return {
    intent: "stop",
    intentDetail: `${INTENT_TAGS.initRejected} ${reason}`,
    ops: [
      { closeStdin: true },
      { signal: "SIGTERM" },
      { signal: "SIGKILL", afterMs: INIT_REJECTED_SIGKILL_AFTER_MS },
    ],
    reason: "worker-failed",
    detail: `the worker failed its start checks: ${reason}`,
    notice: {
      level: "error",
      code: OUTCOME_NOTICES.initRejected,
      text: `${story}: dipo stopped the worker because its start failed the checks (${reason}) and parked the story as worker-failed.`,
    },
  };
}

export interface RunOutcomesDeps {
  /** The story store: the park a pending planning change writes (`plannedPark`, 0010). */
  readonly stories: ParkStore;
  readonly clock: Clock;
  readonly offices: { get(office: OfficeId): OfficeHandle | undefined };
  readonly steering: RunSteering;
  readonly encode: (op: SteerOp) => HostOp[];
  /** The worker port's id and pure `result`. */
  readonly worker: Pick<WorkerPort, "id" | "result">;
  /** Run control; read when needed, since it is built with this as its outcomes. */
  readonly ender: () => RunEnder;
  /** Starts the run's next session; without it every crash parks `worker-failed`. */
  readonly resumer?: NextSession;
  /** The adapter's pause, set for start failures: the office's starts paused (0020). */
  readonly holds?: {
    pause(adapter: string, failures: readonly LaunchCheckFailure[]): AdapterPause;
  };
  /** Releases a live claim whose worker did not start. */
  readonly release?: (office: OfficeId, claim: ClaimRecord, reason: string) => Promise<void>;
  /** True when the run's branch has commits past the claim commit. */
  readonly holdsWork?: (
    office: OfficeId,
    run: StoredRun,
    claim: ClaimRecord | null,
  ) => Promise<boolean>;
  /** The caps of a run that is no longer tracked (after a restart). */
  readonly caps?: (office: OfficeId, run: StoredRun) => Caps | null;
  /** The office's starts paused (0020), which a plan limit pauses; read when needed. */
  readonly startsPaused?: () => StartsPausedPort | undefined;
  /** Lifts a park on the story branch (DIPO-75); without it no parked run resumes. */
  readonly unpark?: UnparkWriter;
  /** Finishes the park resumes a restart interrupted (`Resumption`); the number it finished. */
  readonly recoverParks?: (office: OfficeId, handle: OfficeHandle) => Promise<number> | number;
  /** Reads the story again at its branch tip after the park was lifted there (DIPO-75). */
  readonly refreshStory?: (office: OfficeId, key: StoryKey) => Promise<unknown>;
  readonly onChanged?: (office: OfficeId) => void;
  readonly warn?: (message: string, fields: Readonly<Record<string, unknown>>) => void;
}

export function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/** The one feedback turn "report in the schema" (0008, 0014). */
export function reportFeedbackText(why: string): string {
  return renderTemplate(FEEDBACK_TEMPLATES.report, { why });
}
