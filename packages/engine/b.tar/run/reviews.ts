// Review rounds (0002, DIPO-219): a story that reaches In Review gets its
// review in its own reviewer place, its report is judged by code and its verdict stored by
// code tree key.
//
// - Start. A pending review (`pendingReviews`, fed to the places as `PlacesDeps.pending`) starts
//   through the review starter (`START_KINDS.review`) in the story's own reviewer place: a story
//   waiting for its review holds its run slot (`reviewingRuns`, `PlacesDeps.reviewing`), so it
//   never waits for another story. The starter reads the head's code tree key first: a tree that already has a
//   verdict in the claim takes it without a round (commits that change only the task file never
//   start a review). Otherwise the run reopens for the review (phase `review`, at the start time,
//   while its wait counts from the In Review time), takes the reviewer place, starts or continues
//   its review round (`beginReviewRound`: a new round writes its `review` step, which grows no cap;
//   a fresh session after a failed one adds nothing) and starts a fresh
//   reviewer session with the review task message (`ReviewSessions`).
// - Report. A turn's report valid against the review schema is validated by code
//   (`validateReport`). An invalid report gets one correction turn in the same session
//   (`feedback/review-report.md`); still invalid, the session ends as a crash. Blocking findings
//   whose evidence fails get one correction turn naming them (`feedback/review-evidence.md`);
//   still failing, they are kept as advisory, marked unverified. The verdict is computed
//   (`judgeReview`) and stored as a review gate with its `review_verdicts` row (`gate.decided`); a
//   blocked verdict appends a `review-failed` step. The review period ends (`reviewed`) and the
//   session's stdin is closed. The failed round that reaches the run's review round cap parks
//   `review-blocked` with the blocking findings as detail instead.
// - Failures. The reviewer's own turn or minute cap parks `worker-failed` (run
//   control). A resume of a park that stopped the reviewer starts a fresh review. A crash, a host
//   lost, or a report still invalid after its correction turn ends the agent `review-crashed` and
//   starts one fresh session for the same round; a second failure in the round parks
//   `worker-failed` with the reviewer's last error. The story's budget used up parks
//   `budget-exceeded` (run control). A plan limit pauses the office's starts and parks
//   `worker-failed` as a developer session's does (0020); its resume when the pause lifts starts a
//   fresh review. A start failure or a refused launch check holds the adapter with an `engine.notice`; the
//   story stays In Review and the review waits. A launch plan that refuses the session (a
//   `PlanError`) raises the `run.planRefused` notice with `planRefusedText`, as the worker's launch
//   does, once per run and refusal (DIPO-247).
// - Done on the base (DIPO-239). The starter reads the story on the office base before it reopens
//   anything and asks the one Done check (`decideDone`, DIPO-363) with the run's story PR as dipo
//   recorded it; a story Done gets no round and no session: the run ends done (`#doneOnBase`)
//   with one `review.doneOnBase` notice, and the claim is left to the Done poll or reconcile.
// - Caps (DIPO-247). The reviewer's turn and minute caps are the run's start snapshot; a run that
//   has none takes the office's current ones at its first review start (`snapshotReviewCaps`).
// - After the verdict. Once a reviewer session's exit is decided and its verdict or park ended the
//   review period, `onReviewed` hears it: the head's fix round decides then (DIPO-148).

import type { Clock, IdSource, OfficeId, RunId, StoryKey } from "@dipsaus-orchestrator/contract";

import { appendEntries, type NewEntry } from "../changelog/log";
import type { OfficeConfig } from "../config";
import type { OfficeHandle } from "../db/office";
import type { IngestedExit } from "../ingest/ingestor";
import { reviewEvidenceFeedback, reviewReportFeedback } from "../prompts/feedback";
import { assembleReviewTaskMessage } from "../prompts/review";
import { promptStoryOf } from "../prompts/story";
import { parseStoryDiff, type StoryDiff } from "../review/diff";
import {
  recordReviewVerdict,
  reviewDecidedEntry,
  reviewVerdictForTree,
  type StoredReviewVerdict,
} from "../review/store";
import { evidenceProblems, type ReviewFacts, validateReport } from "../review/validate";
import { judgeReview } from "../review/verdict";
import { recordCrashedEnd } from "../records/agents";
import { proxyRefusalOf } from "../records/proxy-refusals";
import { findStoryPr } from "../records/story-prs";
import { withWorkViews } from "../views/work";
import type {
  HostOp,
  PlanError,
  ReviewFinding,
  ReviewReport,
  SteerOp,
  TurnProblem,
} from "../workers/types";
import { decideDone } from "../worktree/done-check";
import { findClaim } from "../worktree/records";

import { REVIEWER_ROLE, runCaps } from "../records/caps";
import { runConfigOf } from "../records/config-snapshot";
import type { RunSteering } from "./control-types";
import { resolveIntent, runIntents, sendAsIntent, type StoredIntent } from "../records/intents";
import {
  type ExitContext,
  INTENT_TAGS,
  intentRest,
  intentTag,
  OUTCOME_NOTICES,
  type PlanLimitHit,
  planLimitEnding,
  type PlanLimitPauses,
  type RunEnder,
  type RunOutcomesPort,
  type RunView,
} from "./outcome-types";
import { heldByPark, type ParkStore } from "../records/park-state";
import { claimPlace, type PlaceStart, START_KINDS, waitForPlace } from "../run-state/places";
import { LAUNCH_NOTICES, planRefusedText } from "./launch";
import { endRunMarked } from "../ingest/markers";
import { appendRunStep, findRun, type StoredRun } from "../records/run-records";
import { latestDoneReport } from "./report-data";
import type { RunStoryFacts } from "./resume";
import { type ReviewGit, type ReviewSessions, snapshotReviewCaps } from "./review-launch";
import {
  beginReviewRound,
  failedReviewRounds,
  openReviewRound,
  pendingReviews,
  type ReviewRound,
  reviewingRuns,
  takeVerdict,
} from "./review-rounds";
import { endReviewPeriod, reopen, reviewedInReview, reviewPeriodStart } from "../run-state/rounds";
import {
  type AdapterPause,
  type LaunchCheckFailure,
  pauseMessage,
  planLimitPause,
} from "./starts-paused";

/** The tags of the review rounds' intents, at the start of their detail. */
export const REVIEW_TAGS = {
  /** `steer` `review-report <agent> <why>`: the correction turn for an invalid report. */
  report: "review-report",
  /** `steer` `review-evidence <agent>`: the correction turn naming failed findings. */
  evidence: "review-evidence",
  /** `stop` `review-retry <why>`: a failed turn ends the session as a crash. */
  retry: "review-retry",
} as const;

/** `agents.end_reason` of a reviewer session that failed (crash, host lost, no report). */
export const REVIEW_CRASHED_END = "review-crashed";

/** `engine.notice` codes of the review rounds. */
export const REVIEW_NOTICES = {
  /** A reviewer session failed; a fresh one starts, or the review waits. */
  failed: "review.failed",
  startFailed: OUTCOME_NOTICES.startFailed,
  /** The reviewer's read-only copy of a head does not match its tree: the review cannot start. */
  copyMismatch: "review.copyMismatch",
  /** The story is Done on the office base: no review round starts and the run ends done. */
  doneOnBase: "review.doneOnBase",
} as const;

export interface ReviewsDeps {
  /** The story store: the park a pending planning change writes (`plannedPark`, 0010). */
  readonly stories: ParkStore;
  readonly clock: Clock;
  readonly ids: IdSource;
  readonly offices: {
    get(office: OfficeId): OfficeHandle | undefined;
    config(office: OfficeId): OfficeConfig | undefined;
  };
  readonly git: ReviewGit;
  /** The story facts of a run, read on the office base (`baseStoryFacts`). */
  readonly story: (office: OfficeId, run: StoredRun) => Promise<RunStoryFacts>;
  readonly sessions: ReviewSessions;
  readonly steering: RunSteering;
  readonly encode: (op: SteerOp) => HostOp[];
  /** Run control; read when needed, since it is built before this. */
  readonly ender: () => RunEnder | undefined;
  /** The adapter's id, for its pause. */
  readonly adapter: string;
  /** The adapter's pause, set for a start failure: the office's starts paused (0020). */
  readonly holds?: {
    pause(adapter: string, failures: readonly LaunchCheckFailure[]): AdapterPause;
  };
  /** The office's starts paused, which a review's plan limit pauses (0020). */
  readonly startsPaused?: () => PlanLimitPauses | undefined;
  /**
   * Hears a run past its review: a reviewer session's exit once its verdict or park ended the
   * review period, with the agent that exited, or a head that took its tree's verdict without a
   * round, with none. The fix round of the head decides then (DIPO-148), as no reviewer runs.
   */
  readonly onReviewed?: (office: OfficeId, runId: RunId, agent?: string) => void;
  readonly onChanged?: (office: OfficeId) => void;
  readonly warn?: (message: string, fields: Readonly<Record<string, unknown>>) => void;
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/** True for a reviewer session's view. */
export function reviewerView(view: RunView): boolean {
  return view.work.role === REVIEWER_ROLE;
}

/** The park detail of the failed round that reached the cap: its unmet criteria and findings. */
export function blockingDetail(stored: StoredReviewVerdict, failed: number, cap: number): string {
  const lines = [
    ...stored.criteria
      .filter((entry) => entry.status === "unmet")
      .map((entry) => `- criterion #${entry.n} unmet: ${entry.evidence.trim()}`),
    ...stored.findings
      .filter((finding) => finding.severity === "blocking")
      .map((finding) => {
        const where =
          finding.file === undefined
            ? finding.testEntry === undefined
              ? ""
              : ` (test-plan entry #${finding.testEntry})`
            : ` at ${finding.file}${finding.line === undefined ? "" : `:${finding.line}`}`;
        return `- blocking ${finding.kind}${where}: ${finding.text.trim()}`;
      }),
  ];
  return [
    `Review round ${stored.round} at ${stored.commit.slice(0, 7)} was blocked, the ${failed} of ${cap} failed rounds the review allows:`,
    ...lines,
  ].join("\n");
}

/** Why a reviewer session ended, from its exit record. */
function exitWhy(end: IngestedExit | null): string {
  if (end === null) return "the reviewer host died while the daemon was down";
  const { code, signal } = end.exit;
  if (signal !== null) return `the reviewer exited on ${signal}`;
  return code === null ? "the reviewer exited" : `the reviewer exited with code ${code}`;
}

export class Reviews {
  readonly #deps: ReviewsDeps;
  /** Runs whose reviewer exit is being decided now. */
  readonly #deciding = new Set<string>();
  /** `<run>:<head>` of each copy mismatch already noticed. */
  readonly #mismatched = new Set<string>();
  /** `<run>:<message>` of each refused launch plan already noticed. */
  readonly #refused = new Set<string>();

  constructor(deps: ReviewsDeps) {
    this.#deps = deps;
  }

  /** The office's pending reviews, oldest In Review first (`PlacesDeps.pending`). */
  pending(office: OfficeHandle): PlaceStart[] {
    return pendingReviews(this.#deps.stories, office);
  }

  /** The office's runs waiting for their review, pushed or not (`PlacesDeps.reviewing`). */
  reviewing(office: OfficeHandle): RunId[] {
    return reviewingRuns(this.#deps.stories, office);
  }

  /**
   * The review starter (`START_KINDS.review`): see the file comment. True when a reviewer session
   * started; false leaves a reopened run waiting for its place again (`Places`), or a run open
   * at In Review pending.
   */
  async start(officeId: OfficeId, run: StoredRun, start: PlaceStart): Promise<boolean> {
    const office = this.#deps.offices.get(officeId);
    if (office === undefined || run.branch === null || run.story === null) return false;
    if (run.ending !== null) return false;
    // A story parked since its start was queued waits for its resume (`pendingReviews`).
    if (run.key !== null && heldByPark(this.#deps.stories, office, run.key)) return false;
    let facts: RunStoryFacts;
    let head: string;
    let tree: string;
    try {
      facts = await this.#deps.story(officeId, run);
      // The head is read once for the round: its tree key, diff, copy and verdict all use it.
      head = await this.#deps.git.head(officeId, run.branch);
      tree = await this.#deps.git.codeTreeKey(officeId, facts.taskFile, head);
    } catch (error) {
      this.#deps.warn?.("reading a story before its review failed; the review waits", {
        run: run.runId,
        reason: messageOf(error),
      });
      return false;
    }
    // A story the one Done check finds Done (0002), on the office base or through its own merged
    // PR, gets no review round (DIPO-239): the run ends done.
    const claim = findClaim(office, run.runId);
    const done = decideDone({
      claim,
      pr: findStoryPr(office, run.runId),
      baseStatus: facts.view.status,
    });
    if (done !== "notDone") {
      this.#doneOnBase(office, run);
      return false;
    }
    // A code tree with a verdict in the claim is never reviewed again.
    const known = reviewVerdictForTree(office, run.runId, tree);
    if (known !== null) {
      this.#write(office, () => {
        const at = this.#deps.clock.now();
        if (!takeVerdict(office, run.runId, known.verdict, at)) {
          endReviewPeriod(office, run.runId, at, known.verdict);
        }
        return [];
      });
      // The run is past its review with the tree's verdict: a blocked one gets its fix round
      // (DIPO-148).
      const after = findRun(office, run.runId);
      if (after !== null && reviewedInReview(office, after)) {
        this.#deps.onReviewed?.(officeId, run.runId);
      }
      return false;
    }
    const at = this.#deps.clock.now();
    const round = this.#writeWith(
      office,
      (): { value: ReviewRound | null; entries: NewEntry[] } => {
        const current = findRun(office, run.runId);
        if (current === null) return { value: null, entries: [] };
        // A park that landed while the story was read (DIPO-346): no round, the run stays as is.
        if (run.key !== null && heldByPark(this.#deps.stories, office, run.key))
          return { value: null, entries: [] };
        // A pending review reopens the run open at In Review; its wait counts from that time.
        const entries =
          current.endedAt === null
            ? []
            : reopen(office, current, at, { kind: "review", waitingSince: start.since });
        if (findRun(office, run.runId)?.endedAt !== null) return { value: null, entries: [] };
        claimPlace(office, run.runId, at);
        // The reviewer's caps are the run's start snapshot; a run started without them takes the
        // office's current ones at its first review start and keeps them (0020).
        const config = this.#deps.offices.config(officeId);
        if (config !== undefined) snapshotReviewCaps(office, run.runId, config);
        return { value: beginReviewRound(office, current, start.since, at).round, entries };
      },
    );
    if (round === null) return false;
    return this.#launch(office, findRun(office, run.runId) ?? run, facts, head);
  }

  /**
   * Builds the review task message at `head` (read now when not given, for a fresh session after a
   * failed one) and starts a fresh reviewer session on exactly that head; true when it started.
   */
  async #launch(
    office: OfficeHandle,
    run: StoredRun,
    facts: RunStoryFacts,
    given?: string,
  ): Promise<boolean> {
    const officeId = office.officeId as OfficeId;
    const inForce = this.#deps.offices.config(officeId);
    if (inForce === undefined || run.branch === null) return false;
    // The prompt budgets the run started with (its configuration snapshot, DIPO-150).
    const config = runConfigOf(office, run, inForce);
    let taskMessage: string;
    let head: string;
    try {
      head = given ?? (await this.#deps.git.head(officeId, run.branch));
      const base = findClaim(office, run.runId)?.baseSha ?? run.startSha ?? head;
      const { diff, changes } = await this.#deps.git.diff(officeId, base, head);
      const size = await this.#deps.git.sizeClass(officeId, head);
      const previous = this.#lastVerdict(office, run.runId);
      // The worker's test-plan statuses and deviations of its last done report (DIPO-254).
      const done = latestDoneReport(office, run.runId);
      taskMessage = assembleReviewTaskMessage({
        story: promptStoryOf(facts.view, {
          dependencies: facts.dependencies,
          fields: facts.fields,
          taskFile: facts.taskFile,
        }),
        base,
        changes,
        diff,
        gateChanges: run.gateChanges ?? [],
        // Kept on the run when each session ended; the Safe-Chain box may be gone (DIPO-376).
        safeChain: run.safeChain,
        // The stored findings are the reviewer's, judged by code, so their kinds are known.
        ...(previous === null
          ? {}
          : { previousFindings: previous.findings as readonly ReviewFinding[] }),
        ...(done === null
          ? {}
          : { workerReport: { testPlan: done.testPlan, deviations: done.deviations } }),
        diffBudget: config.prompt.budgets.diff[size],
        contractMax: config.prompt.contractMax,
      }).text;
    } catch (error) {
      this.#deps.warn?.("building a review task message failed; the review waits", {
        run: run.runId,
        reason: messageOf(error),
      });
      return false;
    }
    // A park that landed while the round was built starts no reviewer (DIPO-344, DIPO-360).
    if (this.#parkedMeanwhile(office, run)) return false;
    let outcome;
    try {
      outcome = await this.#deps.sessions.start({
        office: officeId,
        run,
        taskMessage,
        head,
        held: () => run.key !== null && heldByPark(this.#deps.stories, office, run.key),
      });
    } catch (error) {
      outcome = { kind: "failed" as const, reason: messageOf(error) };
    }
    switch (outcome.kind) {
      case "started":
        return true;
      case "startFailed":
        this.#startFailed(office, run, pauseMessage(outcome.pause));
        return false;
      case "failed":
        // Refused for a park, or for a branch the park's commit moved: the round's head is
        // dropped; the resume, or the next drain of an unparked story, reads the branch again.
        if (this.#parkedMeanwhile(office, run)) return false;
        this.#deps.warn?.("a reviewer session did not start; the review waits", {
          run: run.runId,
          reason: outcome.reason,
        });
        if (outcome.copyMismatch === true) this.#copyMismatch(office, run, head, outcome.reason);
        if (outcome.planRefused !== undefined) this.#planRefused(office, run, outcome.planRefused);
        return false;
    }
  }

  /**
   * True when the run's story is held by a park now (DIPO-346): a park that landed while its review
   * round was built. The round's head is dropped and no reviewer starts. The park ended the run the
   * round had reopened, so nothing waits for the place, and `pendingReviews` skips the story until
   * its resume, whose round reads the branch again.
   */
  #parkedMeanwhile(office: OfficeHandle, run: StoredRun): boolean {
    if (run.key === null || !heldByPark(this.#deps.stories, office, run.key)) return false;
    this.#deps.warn?.("the story parked while its review round was built; no reviewer starts", {
      run: run.runId,
    });
    return true;
  }

  /**
   * A story Done on the office base (DIPO-239): no review round and no session. The run ends done
   * in one write, with its final outcome row: a run open at In Review keeps the end of its last
   * active period; a run reopened and waiting for the reviewer place ends with its review period's
   * time left out, its wait cleared and its place free. One info notice names the story and the run. The
   * claim stays live for reconcile's done-on-base release (DIPO-216).
   */
  #doneOnBase(office: OfficeHandle, run: StoredRun): void {
    const story = run.story ?? run.runId;
    this.#write(office, () => {
      const current = findRun(office, run.runId);
      if (current === null || current.ending === "done") return [];
      const at = this.#deps.clock.now();
      if (!endRunMarked(office, run.runId, at, "done", reviewPeriodStart(office, run.runId))) {
        return [];
      }
      return [
        {
          type: "engine.notice",
          ...(run.key === null ? {} : { key: run.key }),
          run: run.runId,
          delta: {
            level: "info",
            code: REVIEW_NOTICES.doneOnBase,
            text: `${story} is Done on the office base, so dipo starts no review for run ${run.runId} and ends the run as done. Reconcile releases its claim.`,
          },
        },
      ];
    });
  }

  /**
   * A copy that does not match its head's tree (DIPO-276), for example two paths that differ only
   * in case, which the Mac's file system folds into one: a notice for the maintainer, once per head
   * in this daemon, so a commit cannot stall its own review unseen. The story stays In Review.
   */
  #copyMismatch(office: OfficeHandle, run: StoredRun, head: string, why: string): void {
    const seen = `${run.runId}:${head}`;
    if (this.#mismatched.has(seen)) return;
    this.#mismatched.add(seen);
    const story = run.story ?? run.runId;
    this.#write(office, () => [
      {
        type: "engine.notice",
        ...(run.key === null ? {} : { key: run.key }),
        run: run.runId,
        delta: {
          level: "warn",
          code: REVIEW_NOTICES.copyMismatch,
          text: `${story}: the review cannot start: ${why}. The commit may hold paths that differ only in case, which this Mac's file system folds into one. The story stays In Review until its branch changes; check the commit.`,
        },
      },
    ]);
  }

  /**
   * A reviewer launch the plan refused (`PlanError`, DIPO-247): the `run.planRefused` notice on the
   * office with `planRefusedText`, as the worker's launch raises it, once per run and refusal in
   * this daemon, as the review is tried again at every drain. The story stays In Review.
   */
  #planRefused(office: OfficeHandle, run: StoredRun, error: PlanError): void {
    const seen = `${run.runId}:${error.message}`;
    if (this.#refused.has(seen)) return;
    this.#refused.add(seen);
    this.#write(office, () => [
      {
        type: "engine.notice",
        ...(run.key === null ? {} : { key: run.key }),
        run: run.runId,
        delta: {
          level: "error",
          code: LAUNCH_NOTICES.planRefused,
          text: planRefusedText(run.story ?? run.runId, error),
        },
      },
    ]);
  }

  /** A reviewer session that failed to start: a notice; the story stays In Review, the review waits. */
  #startFailed(office: OfficeHandle, run: StoredRun, why: string): void {
    const story = run.story ?? run.runId;
    this.#write(office, () => [
      {
        type: "engine.notice",
        ...(run.key === null ? {} : { key: run.key }),
        run: run.runId,
        delta: {
          level: "error",
          code: REVIEW_NOTICES.startFailed,
          text: `${story}: the reviewer did not start (${why}). The story stays In Review and its review waits.`,
        },
      },
    ]);
  }

  /** The run's newest verdict, the previous round's on a re-review. */
  #lastVerdict(office: OfficeHandle, runId: RunId): StoredReviewVerdict | null {
    const row = office.get<{ code_tree_key: string }>(
      `select code_tree_key from review_verdicts where office_id = $office_id and run_id = $run
        order by decided_at desc, rowid desc limit 1`,
      { run: runId },
    );
    return row === null ? null : reviewVerdictForTree(office, runId, row.code_tree_key);
  }

  // ---- the session's turns ---------------------------------------------------------------------

  /** A reviewer turn's report valid against the schema: validate, correct once, judge, store. */
  async onReview(view: RunView, report: ReviewReport): Promise<void> {
    const office = this.#deps.offices.get(view.office);
    if (office === undefined) return;
    const run = findRun(office, view.runId);
    if (run === null || run.endedAt !== null || run.branch === null) return;
    const agent = view.work.agent;
    let reviewed: { facts: ReviewFacts; commit: string; tree: string };
    try {
      reviewed = await this.#reviewed(view.office, run, agent);
    } catch (error) {
      this.#crash(view, `the reviewed commit could not be read: ${messageOf(error)}`);
      return;
    }
    const check = validateReport(report, reviewed.facts);
    if (!check.valid) {
      await this.#invalid(office, view, check.problems.join("; "));
      return;
    }
    const failed = evidenceProblems(check.findings);
    if (failed.length > 0 && this.#sent(office, view.runId, REVIEW_TAGS.evidence, agent) === null) {
      await this.#correct(office, view, REVIEW_TAGS.evidence, reviewEvidenceFeedback(failed));
      return;
    }
    const judged = judgeReview(report, check.findings);
    const at = this.#deps.clock.now();
    const decided = this.#writeWith(office, () => {
      const current = findRun(office, run.runId);
      if (current === null || current.endedAt !== null) return { value: null, entries: [] };
      const round = openReviewRound(office, run.runId)?.round ?? 1;
      const stored = recordReviewVerdict(office, this.#deps.ids, {
        runId: run.runId,
        key: run.key as StoryKey,
        round,
        agent,
        model: view.work.model,
        commit: reviewed.commit,
        codeTreeKey: reviewed.tree,
        judged,
        at,
      });
      if (judged.verdict === "blocked") {
        appendRunStep(office, run.runId, "review-failed", String(round), at);
      }
      const cap = runCaps(office, current).reviewRoundCap;
      const capped =
        judged.verdict === "blocked" &&
        cap !== null &&
        failedReviewRounds(office, run.runId) >= cap;
      if (!capped) endReviewPeriod(office, run.runId, at, judged.verdict);
      return { value: { stored, capped }, entries: [reviewDecidedEntry(stored)] };
    });
    if (decided === null) return;
    if (decided.capped) {
      const cap = runCaps(office, run).reviewRoundCap ?? 0;
      this.#deps.ender()?.begin(view.runId, {
        intent: "park",
        ops: [{ closeStdin: true }],
        reason: "review-blocked",
        detail: blockingDetail(decided.stored, failedReviewRounds(office, run.runId), cap),
      });
      return;
    }
    // The verdict explains the exit, as a done report does: stdin closes with no intent.
    await this.#deps.steering.send(office, view.runId, [{ closeStdin: true }]).catch(() => {
      // A reviewer that already exited needs nothing more.
    });
  }

  /**
   * The facts a report is judged against, at the reviewed commit: the head the session was given
   * (its copy's, `reviewedCommit`), else the branch tip. A branch that moved since the session
   * started throws, so the session ends as a crash and a fresh one reviews the new head.
   */
  async #reviewed(
    officeId: OfficeId,
    run: StoredRun,
    agent: string,
  ): Promise<{ facts: ReviewFacts; commit: string; tree: string }> {
    const office = this.#deps.offices.get(officeId);
    const branch = run.branch as string;
    const story = await this.#deps.story(officeId, run);
    const now = await this.#deps.git.head(officeId, branch);
    const base =
      (office === undefined ? null : findClaim(office, run.runId)?.baseSha) ?? run.startSha ?? now;
    const commit = (await this.#deps.sessions.reviewedCommit?.(officeId, run.runId, agent)) ?? now;
    if (commit !== now) {
      throw new Error(`the story branch moved from ${commit} to ${now} during the review`);
    }
    const tree = await this.#deps.git.codeTreeKey(officeId, story.taskFile, commit);
    const { diff } = await this.#deps.git.diff(officeId, base, commit);
    const parsed = parseStoryDiff(diff);
    const files: StoryDiff = {
      files: new Map([...parsed.files].filter(([path]) => path !== story.taskFile)),
    };
    return {
      facts: {
        criteria: story.view.acceptanceCriteria.map((criterion) => criterion.index),
        testPlan: story.fields.test_plan,
        diff: files,
      },
      commit,
      tree,
    };
  }

  /** An invalid report: one correction turn in the same session; still invalid, as a crash. */
  async #invalid(office: OfficeHandle, view: RunView, why: string): Promise<void> {
    if (this.#sent(office, view.runId, REVIEW_TAGS.report, view.work.agent) !== null) {
      this.#crash(view, `no valid review report after the correction turn: ${why}`);
      return;
    }
    await this.#correct(office, view, REVIEW_TAGS.report, reviewReportFeedback(why), why);
  }

  /** The newest correction turn of `tag` sent to `agent`, or null. */
  #sent(office: OfficeHandle, runId: RunId, tag: string, agent: string): StoredIntent | null {
    return (
      runIntents(office, runId)
        .filter(
          (intent) =>
            intent.kind === "steer" &&
            intentTag(intent.detail) === tag &&
            intentRest(intent.detail).split(" ")[0] === agent,
        )
        .at(-1) ?? null
    );
  }

  /** Sends one correction turn, stored first as a `steer` intent. */
  async #correct(
    office: OfficeHandle,
    view: RunView,
    tag: string,
    text: string,
    why = "",
  ): Promise<void> {
    await sendAsIntent(office, this.#deps.steering, view.runId, {
      kind: "steer",
      detail: `${tag} ${view.work.agent}${why === "" ? "" : ` ${why}`}`,
      ops: this.#deps.encode({ kind: "steer", text }),
      clock: this.#deps.clock,
    }).done;
  }

  /** Ends the session as a crash: its exit starts one fresh session or parks. */
  #crash(view: RunView, why: string): void {
    this.#deps.ender()?.act(view.runId, {
      intent: "stop",
      detail: `${REVIEW_TAGS.retry} ${why}`,
      ops: [{ closeStdin: true }, { signal: "SIGTERM", afterMs: 10_000 }],
      retryAtTick: true,
    });
  }

  /** A turn's problem in a reviewer session. */
  async onTurnProblem(view: RunView, problem: TurnProblem): Promise<void> {
    const office = this.#deps.offices.get(view.office);
    if (office === undefined || this.#deps.ender()?.live(view.runId) !== true) return;
    switch (problem.kind) {
      case "report":
        await this.#invalid(office, view, problem.detail);
        return;
      case "planLimit":
        this.onPlanLimit(view, {
          credits: false,
          ...(problem.http429 === true ? { http429: true as const } : {}),
        });
        return;
      case "startFailed":
        this.#deps.ender()?.act(view.runId, {
          intent: "stop",
          detail: `${INTENT_TAGS.startFailed} ${problem.detail}`,
          ops: [{ closeStdin: true }, { signal: "SIGTERM", afterMs: 10_000 }],
          retryAtTick: true,
        });
        return;
      case "contextFull":
      case "error":
        this.#crash(view, problem.detail);
        return;
    }
  }

  /**
   * A plan limit in a review (0020): the office's starts pause, and the session ends with its
   * story parked `worker-failed`, as a developer session's does. The park resumes by itself when
   * the pause lifts, and that resume starts a fresh review of the same head (0002).
   */
  onPlanLimit(view: RunView, limit: PlanLimitHit): void {
    // A 429 the model proxy sent at the reviewer's token cap is that cap, not the plan (DIPO-484).
    const office = this.#deps.offices.get(view.office);
    const refusal =
      limit.http429 === true && office !== undefined
        ? proxyRefusalOf(office, view.runId, view.work.agent, this.#deps.clock.now())
        : null;
    if (refusal !== null) {
      this.#deps.ender()?.begin(view.runId, {
        intent: "cap",
        ops: [{ closeStdin: true }, { signal: "SIGTERM", afterMs: 10_000 }],
        reason: "budget-exceeded",
        detail: refusal,
      });
      return;
    }
    const pause = planLimitPause(limit, this.#deps.clock.now());
    this.#deps.startsPaused?.()?.pausePlanLimit(view.office, pause);
    this.#deps
      .ender()
      ?.begin(
        view.runId,
        planLimitEnding(pause, [{ closeStdin: true }, { signal: "SIGTERM", afterMs: 10_000 }]),
      );
  }

  // ---- the session's exit ----------------------------------------------------------------------

  /** A reviewer session exited: see the file comment. */
  async onExit(exit: ExitContext): Promise<void> {
    await exit.turns.catch(() => undefined);
    await exit.ending?.catch(() => undefined);
    await this.#finish(exit.view, exit.agent);
    await this.#decide(exit.view, exit.agent, exit.end);
  }

  /** The ended session's reviewer box goes (0002); a failure is left for the daemon-start sweep. */
  async #finish(view: RunView, agent: string): Promise<void> {
    await this.#deps.sessions.finish?.(view.office, view.runId, agent).catch((error: unknown) => {
      this.#deps.warn?.("a reviewer's box could not be deleted", {
        run: view.runId,
        reason: messageOf(error),
      });
    });
  }

  async #decide(view: RunView, agent: string, end: IngestedExit | null): Promise<void> {
    if (this.#deciding.has(view.runId)) return;
    this.#deciding.add(view.runId);
    try {
      await this.#decideExit(view, agent, end);
    } finally {
      this.#deciding.delete(view.runId);
    }
  }

  async #decideExit(view: RunView, agent: string, end: IngestedExit | null): Promise<void> {
    const office = this.#deps.offices.get(view.office);
    if (office === undefined) return;
    const run = findRun(office, view.runId);
    if (run === null) return;
    const at = this.#deps.clock.now();
    const intent = explaining(office, view.runId);
    const tag = intent === null ? null : intentTag(intent.detail);
    if (run.endedAt !== null) {
      // A verdict, or a park, ended the run already.
      if (intent !== null) this.#resolve(office, view.runId, intent, intent.kind, at);
      // No reviewer runs any more: the fix round of this head may decide now (DIPO-148).
      this.#deps.onReviewed?.(view.office, view.runId, agent);
      return;
    }
    if (tag === INTENT_TAGS.startFailed && intent !== null) {
      this.#resolve(office, view.runId, intent, "startFailed", at);
      const why = intentRest(intent.detail);
      const hold = this.#deps.holds?.pause(this.#deps.adapter, [
        { check: "start-failed", detail: why },
      ]);
      this.#startFailed(office, run, hold === undefined ? why : pauseMessage(hold));
      this.#waitAgain(office, run);
      return;
    }
    // A crash: no verdict and no decision that explains the exit.
    const why =
      tag === REVIEW_TAGS.retry && intent !== null ? intentRest(intent.detail) : exitWhy(end);
    if (intent !== null) this.#resolve(office, view.runId, intent, "crashed", at);
    const round = openReviewRound(office, run.runId);
    const crashes = office.immediate(() => {
      recordCrashedEnd(office, agent, at, REVIEW_CRASHED_END);
      return (
        office.get<{ n: number }>(
          `select count(*) as n from agents where office_id = $office_id and run_id = $run
            and role = $role and end_reason = $reason and started_at >= $since`,
          {
            run: run.runId,
            role: REVIEWER_ROLE,
            reason: REVIEW_CRASHED_END,
            since: round?.at ?? 0,
          },
        )?.n ?? 0
      );
    });
    const ender = this.#deps.ender();
    if (crashes >= 2 || ender === undefined) {
      await ender?.park(office, run, view.work, {
        intent: "park",
        ops: [],
        reason: "worker-failed",
        detail: `the reviewer failed twice in review round ${round?.round ?? 1}: ${why}`,
      });
      return;
    }
    // One fresh session for the same round; the round is not counted again.
    this.#write(office, () => [
      {
        type: "engine.notice",
        ...(run.key === null ? {} : { key: run.key }),
        run: run.runId,
        delta: {
          level: "warn",
          code: REVIEW_NOTICES.failed,
          text: `${run.story ?? run.runId}: the reviewer failed (${why}); dipo starts one fresh review session for review round ${round?.round ?? 1}.`,
        },
      },
    ]);
    let started = false;
    try {
      started = await this.#launch(office, run, await this.#deps.story(view.office, run));
    } catch (error) {
      this.#deps.warn?.("starting a fresh review session failed; the review waits", {
        run: run.runId,
        reason: messageOf(error),
      });
    }
    if (!started) this.#waitAgain(office, run);
  }

  /** The open review waits for the reviewer place again, from its In Review time. */
  #waitAgain(office: OfficeHandle, run: StoredRun): void {
    const since = openReviewRound(office, run.runId)?.since ?? this.#deps.clock.now();
    office.immediate(() => waitForPlace(office, run.runId, START_KINDS.review, since));
    this.#deps.onChanged?.(office.officeId as OfficeId);
  }

  #resolve(
    office: OfficeHandle,
    runId: RunId,
    intent: StoredIntent,
    outcome: string,
    at: number,
  ): void {
    office.immediate(() => resolveIntent(office, runId, intent.intentId, outcome, at));
  }

  /** Runs `fn` in one transaction and appends the entries it returns with their work views. */
  #write(office: OfficeHandle, fn: () => readonly NewEntry[]): void {
    this.#writeWith(office, () => ({ value: undefined, entries: fn() }));
  }

  /** `#write` for a step that also returns a value. */
  #writeWith<T>(
    office: OfficeHandle,
    fn: () => { readonly value: T; readonly entries: readonly NewEntry[] },
  ): T {
    const at = this.#deps.clock.now();
    const { value, appended } = office.immediate(() => {
      const out = fn();
      const entries = withWorkViews(office, out.entries);
      appendEntries(office, entries, { at });
      return { value: out.value, appended: entries.length };
    });
    if (appended > 0) this.#deps.onChanged?.(office.officeId as OfficeId);
    return value;
  }

  /**
   * Worker outcomes for both kinds of session: a reviewer session's turns and exit are decided
   * here, every other session's by `base`.
   */
  route(base: RunOutcomesPort): RunOutcomesPort {
    return {
      onTurnProblem: (view, problem) =>
        reviewerView(view) ? this.onTurnProblem(view, problem) : base.onTurnProblem(view, problem),
      onPlanLimit: (view, limit) =>
        reviewerView(view) ? this.onPlanLimit(view, limit) : base.onPlanLimit(view, limit),
      onModelSwitched: (view, model) => base.onModelSwitched(view, model),
      // A reviewer answers no report feedback of the developer's.
      answered: (view) => {
        if (!reviewerView(view)) base.answered(view);
      },
      onReview: (view, report) =>
        reviewerView(view) ? this.onReview(view, report) : Promise.resolve(),
      onExit: (exit) => (reviewerView(exit.view) ? this.onExit(exit) : base.onExit(exit)),
    };
  }
}

/** The newest unresolved intent that explains a worker's exit. */
function explaining(office: OfficeHandle, runId: RunId): StoredIntent | null {
  return (
    runIntents(office, runId)
      .filter(
        (intent) =>
          intent.resolvedAt === null &&
          (intent.kind === "stop" ||
            intent.kind === "cap" ||
            intent.kind === "park" ||
            intent.kind === "new-session"),
      )
      .at(-1) ?? null
  );
}
