// A story's current park (0001, 0007, 0010): the one way the engine asks
// whether a story is parked, why and from where. Backlog.md owns the status and the park record
// (the `dipo` field block's `park: {reason, from, note}`); the engine reads them as the story
// index last read them (`backlog_mirror`, refreshed after every park and lift commit, and set from
// the park's read-back in the park's own transaction), or as an open planning-lane operation
// writes them before its backlog PR merges (0010: a pending operation wins), which the engine asks
// the StoryStore (`plannedPark`) and never reads from the journal itself. The `parks` table is
// run detail and history only: its open row gives the park's id, run, detail, last good commit and
// time, and its `reason` column is the reason the park was made with, never read here.
//
// A story is parked only while Backlog.md says so: status Parked with a park record. An open
// `parks` row without that record (a park never written to Backlog.md) is not a park; reconcile
// closes it with a notice. A park record with no open row is a park without run detail until
// reconcile records it.

import {
  FieldBlockPark,
  type Lifecycle,
  type ParkReason,
  type StoryKey,
} from "@dipsaus-orchestrator/contract";

import type { OfficeHandle } from "../db/office";
import type { StoryStore } from "../story-store/store";

/** What a park read asks the StoryStore (0010): the park a pending planning change writes. */
export type ParkStore = Pick<StoryStore, "plannedPark" | "planningHold">;

/** The park record Backlog.md holds for a story. */
export interface BacklogPark {
  readonly reason: ParkReason;
  readonly from: Lifecycle;
  readonly note: string;
}

/** A story's current park: Backlog.md's record with the run detail of its open `parks` row. */
export interface OpenPark {
  readonly parkId: number;
  /** From Backlog.md. */
  readonly reason: ParkReason;
  /** From Backlog.md: the lifecycle the story returns to on resume. */
  readonly from: Lifecycle;
  readonly detail: string;
  readonly runId: string | null;
  readonly lastGoodCommit: string | null;
  readonly at: number;
}

function parkOf(json: unknown): BacklogPark | null {
  const parsed = FieldBlockPark.safeParse(json);
  return parsed.success ? parsed.data : null;
}

/**
 * The park record Backlog.md holds for the story `key` now, or null when it is not Parked there:
 * the park a pending planning change writes first (`StoryStore.plannedPark`), else the story
 * index's read (status Parked with a park record).
 */
export function backlogPark(
  stories: ParkStore,
  office: OfficeHandle,
  key: StoryKey | string,
): BacklogPark | null {
  const lane = stories.plannedPark(office, key);
  if (lane !== undefined) return lane;
  const row = office.get<{ kind: string; status: string; park: string | null }>(
    `select kind, status, park from backlog_mirror where office_id = $office_id and key = $key`,
    { key },
  );
  if (row === null || row.kind !== "task" || row.status !== "Parked" || row.park === null) {
    return null;
  }
  return parkOf(JSON.parse(row.park));
}

/** The tag of a maintainer resume's `answer` intent: `maintainer-resume <ResumeIntent JSON>`. */
export const MAINTAINER_RESUME_TAG = "maintainer-resume";

/**
 * The parks an unresolved maintainer resume is lifting (DIPO-360): its lift may be on the branch
 * already, so Backlog.md no longer holds the park while its row stays open until `recover` finishes
 * the resume. Reconcile leaves those rows to it.
 */
export function parksBeingResumed(office: OfficeHandle): ReadonlySet<number> {
  const parks = new Set<number>();
  for (const row of office.all<{ detail: string }>(
    `select detail from run_intents where office_id = $office_id and kind = 'answer'
      and resolved_at is null and detail like $tag`,
    { tag: `${MAINTAINER_RESUME_TAG} %` },
  )) {
    try {
      const parsed = JSON.parse(row.detail.slice(MAINTAINER_RESUME_TAG.length + 1)) as {
        parkId?: unknown;
      };
      if (typeof parsed.parkId === "number") parks.add(parsed.parkId);
    } catch {
      // Not a resume intent dipo wrote: it lifts no park.
    }
  }
  return parks;
}

/** The newest open `parks` row of the story: run detail only. */
function openParkRow(office: OfficeHandle, key: string): Omit<OpenPark, "reason" | "from"> | null {
  const row = office.get<{
    park_id: number;
    detail: string;
    run_id: string | null;
    last_good_commit: string | null;
    at: number;
  }>(
    `select park_id, detail, run_id, last_good_commit, at from parks
     where office_id = $office_id and key = $key and resolved_at is null
     order by park_id desc limit 1`,
    { key },
  );
  return row === null
    ? null
    : {
        parkId: row.park_id,
        detail: row.detail,
        runId: row.run_id,
        lastGoodCommit: row.last_good_commit,
        at: row.at,
      };
}

/**
 * The story's current park, or null when it is not parked: Backlog.md's park record (its reason
 * and origin) with the run detail of the open `parks` row. Null when either is missing; see the
 * file comment.
 */
export function openPark(
  stories: ParkStore,
  office: OfficeHandle,
  key: StoryKey | string,
): OpenPark | null {
  const park = backlogPark(stories, office, key);
  if (park === null) return null;
  const row = openParkRow(office, key);
  return row === null ? null : { ...row, reason: park.reason, from: park.from };
}

/**
 * Inside the park's transaction (DIPO-360): the story index's read of the story set to what the
 * park write read back on the story branch (status Parked and the park record), so every reader
 * sees the park at once; the refresh after the commit reads the whole story again. A story the
 * index never read keeps no row.
 */
export function mirrorPark(
  office: OfficeHandle,
  key: StoryKey | string,
  park: BacklogPark,
  at: number,
): void {
  const json = JSON.stringify({ reason: park.reason, from: park.from, note: park.note });
  office.run(
    `update backlog_mirror set status = 'Parked',
       park_since = case when park is $park then park_since else $at end, park = $park
     where office_id = $office_id and key = $key and kind = 'task'`,
    { key, park: json, at },
  );
}

/**
 * Inside the lift's transaction (DIPO-360): the story index's read of the story set to what the
 * lift wrote on the story branch (status `to`, no park record).
 */
export function mirrorUnpark(office: OfficeHandle, key: StoryKey | string, to: Lifecycle): void {
  office.run(
    `update backlog_mirror set status = $to, park = null, park_since = null
     where office_id = $office_id and key = $key and kind = 'task'`,
    { key, to },
  );
}

/** True when the story of the run `runId` is parked (`openPark`); false for a run with no story. */
export function parkedRun(stories: ParkStore, office: OfficeHandle, runId: string): boolean {
  const row = office.get<{ key: string | null }>(
    "select key from runs where office_id = $office_id and run_id = $run",
    { run: runId },
  );
  return row?.key != null && openPark(stories, office, row.key) !== null;
}

/**
 * The park `parkId` as a resume captured it, while its `parks` row is still unresolved (DIPO-360):
 * run detail, for a resume's idempotency once its lift may already be on the branch, so not the
 * current state. The reason is the one the resume captured from Backlog.md before the lift.
 */
export function unresolvedPark(
  office: OfficeHandle,
  key: string,
  parkId: number,
  captured: { readonly reason: string; readonly from: Lifecycle },
): OpenPark | null {
  const row = office.get<{
    detail: string;
    run_id: string | null;
    last_good_commit: string | null;
    at: number;
  }>(
    `select detail, run_id, last_good_commit, at from parks
      where office_id = $office_id and park_id = $park and key = $key and resolved_at is null`,
    { park: parkId, key },
  );
  return row === null
    ? null
    : {
        parkId,
        reason: captured.reason as ParkReason,
        from: captured.from,
        detail: row.detail,
        runId: row.run_id,
        lastGoodCommit: row.last_good_commit,
        at: row.at,
      };
}

/**
 * The fail-closed guard of the work that follows a story's run (DIPO-360). The rule: an open park
 * row whose park was never written to Backlog.md keeps the guards closed, until reconcile or a
 * resume resolves the row. It is the fail-closed counterpart of "a pending lane operation wins"
 * (0010): what dipo has stopped but Backlog.md does not hold yet still holds the story, as a
 * journaled park holds a story before its backlog PR merges. So the auto-merge, the reviewer, fix
 * rounds and the Done teardown start while neither Backlog.md holds a park nor a park row is open.
 * The current reason and origin stay Backlog.md's alone (`openPark`).
 */
export function heldByPark(
  stories: ParkStore,
  office: OfficeHandle,
  key: StoryKey | string,
): boolean {
  if (backlogPark(stories, office, key) !== null) return true;
  return (
    office.get(
      `select 1 as found from parks where office_id = $office_id and key = $key
        and resolved_at is null limit 1`,
      { key },
    ) !== null
  );
}

/** `heldByPark` of the story of the run `runId`; false for a run with no story. */
export function runHeldByPark(stories: ParkStore, office: OfficeHandle, runId: string): boolean {
  const row = office.get<{ key: string | null }>(
    "select key from runs where office_id = $office_id and run_id = $run",
    { run: runId },
  );
  return row?.key != null && heldByPark(stories, office, row.key);
}

/**
 * Why an open park row holds a story Backlog.md does not hold as parked (DIPO-360): its write to
 * Backlog.md failed (`unwritten`: a run's park with no park commit), a maintainer resume is
 * lifting it (`resuming`), or Backlog.md no longer holds a park dipo wrote (`lifted`, by hand).
 */
export type HeldParkWhy = "unwritten" | "resuming" | "lifted";

/**
 * Open `parks` rows of stories Backlog.md does not hold as parked, newest row per story, with why
 * (`HeldParkWhy`): each holds the story's work (`heldByPark`) until a resume, a park written again
 * or a rescan's reconcile resolves it.
 */
export function heldParks(
  stories: ParkStore,
  office: OfficeHandle,
): {
  readonly key: string;
  readonly story: string;
  readonly detail: string;
  readonly at: number;
  readonly why: HeldParkWhy;
}[] {
  const rows = office.all<{
    park_id: number;
    key: string;
    story_id: string;
    run_id: string | null;
    last_good_commit: string | null;
    detail: string;
    at: number;
  }>(
    `select park_id, key, story_id, run_id, last_good_commit, detail, at from parks p
      where office_id = $office_id and resolved_at is null
        and park_id = (select max(park_id) from parks q where q.office_id = p.office_id
          and q.key = p.key and q.resolved_at is null)
      order by at, park_id`,
  );
  const resuming = parksBeingResumed(office);
  return (
    rows
      // A park whose hold failed to write is the planning lane's desk item (DIPO-401).
      .filter(
        (row) =>
          backlogPark(stories, office, row.key) === null &&
          stories.planningHold(office, row.key as StoryKey) !== "holdFailed",
      )
      .map((row) => ({
        key: row.key,
        story: row.story_id,
        detail: row.detail,
        at: row.at,
        why: resuming.has(row.park_id)
          ? ("resuming" as const)
          : row.run_id !== null && row.last_good_commit === null
            ? ("unwritten" as const)
            : ("lifted" as const),
      }))
  );
}
