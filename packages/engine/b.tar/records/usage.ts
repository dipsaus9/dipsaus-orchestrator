// Usage facts (0007, 0008). Each counted assistant message is one
// `usage_messages` row, unique per office, agent and message id; its tokens join the agent's
// `usage_totals` row for that model in the same transaction. At a turn end the adapter's
// cumulative totals replace the live numbers. `usage_daily` is fed only when a totals row
// becomes final. Budget tokens are input plus output plus cache creation; cache reads are stored
// and shown, never counted.
//
// The live numbers (DIPO-296): until the turn end, the adapter reports the turn in progress (the
// main agent's model turns and the output it knows of so far), stored on the agent's main model
// row in `live_turns` and `live_output`. `readUsage` adds them to the turns and output it shows,
// so the live view counts during a session; the caps, `budget_used` and `usage_daily` never read
// them. The turn end and the agent's end set them to 0.
//
// A session in a box (DIPO-425, 0008): dipo's model proxy counts every model request the box makes
// (`recordProxiedUsage`), and that count is the token total. The stream of such a session adds no
// tokens: its turn end adds its turns to the model row (`applyProxiedTurn`) and keeps the cost the
// CLI reports (`recordProxiedCost`), so a Claude Code turn is counted once. Both key a model by its
// canonical id, so the proxy's tokens and the CLI's cost meet on one row.
//
// Every function here writes or reads through the office handle and must run inside the caller's
// transaction.

import type { Usage, UsageTotals } from "@dipsaus-orchestrator/contract";

import type { OfficeHandle } from "../db/office";
import type { ModelUsageTotals, UsageTotalsByModel } from "../workers/types";

import { REVIEWER_ROLE } from "./caps";

/** The run and agent usage is counted for, with what `runs` holds for it. */
export interface UsageScope {
  readonly run: string;
  readonly agent: string;
  readonly role: string;
  readonly tier: string;
  /** The run's budget limit in tokens (0008). */
  readonly budgetLimit: number;
}

const DATE_SUFFIX = /-\d{8}$/;
const CONTEXT_SUFFIX = /\[[^\]]*\]$/;

/**
 * The canonical id of a reported model id: a context-window marker (`[1m]`) and a snapshot date
 * suffix (`-20250929`) are dropped, so turn totals keyed `claude-opus-5-5[1m]` match the messages
 * the API answered as `claude-opus-5-5`.
 */
export function canonicalModel(model: string): string {
  return model.trim().toLowerCase().replace(CONTEXT_SUFFIX, "").replace(DATE_SUFFIX, "");
}

/** Budget tokens of one set of numbers (0008). */
export function budgetOf(usage: ModelUsageTotals): number {
  return usage.input + usage.output + usage.cacheCreate;
}

function ensureRow(office: OfficeHandle, scope: UsageScope, model: string, at: number): void {
  office.run(
    `insert or ignore into usage_totals (office_id, run_id, agent_id, model, role, tier,
       budget_limit, updated_at)
     values ($office_id, $run, $agent, $model, $role, $tier, $limit, $at)`,
    {
      run: scope.run,
      agent: scope.agent,
      model,
      role: scope.role,
      tier: scope.tier,
      limit: scope.budgetLimit,
      at,
    },
  );
}

const BUDGET_UPDATE = "budget_used = input + output + cache_create";

/** One counted assistant message. Returns false when it was already counted. */
export function recordUsageMessage(
  office: OfficeHandle,
  scope: UsageScope,
  message: {
    readonly messageId: string;
    readonly model: string;
    readonly input: number;
    readonly output: number;
    readonly cacheCreate: number;
    readonly cacheCreate5m: number;
    readonly cacheCreate1h: number;
    readonly cacheRead: number;
  },
  at: number,
): boolean {
  const inserted = office.run(
    `insert or ignore into usage_messages (office_id, agent_id, message_id, run_id, model, input,
       output, cache_create, cache_create_5m, cache_create_1h, cache_read, at)
     values ($office_id, $agent, $message, $run, $model, $input, $output, $create, $create5m,
       $create1h, $read, $at)`,
    {
      agent: scope.agent,
      message: message.messageId,
      run: scope.run,
      model: message.model,
      input: message.input,
      output: message.output,
      create: message.cacheCreate,
      create5m: message.cacheCreate5m,
      create1h: message.cacheCreate1h,
      read: message.cacheRead,
      at,
    },
  );
  if (inserted.changes === 0) return false;
  ensureRow(office, scope, message.model, at);
  // Live output stays out of the totals: per-message output may be a placeholder (0008).
  office.run(
    `update usage_totals set input = input + $input, cache_create = cache_create + $create,
       cache_create_5m = cache_create_5m + $create5m, cache_create_1h = cache_create_1h + $create1h,
       cache_read = cache_read + $read, updated_at = $at
     where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
    {
      input: message.input,
      create: message.cacheCreate,
      create5m: message.cacheCreate5m,
      create1h: message.cacheCreate1h,
      read: message.cacheRead,
      at,
      run: scope.run,
      agent: scope.agent,
      model: message.model,
    },
  );
  setBudget(office, scope);
  return true;
}

/** The tokens of one model answer the model proxy passed (DIPO-425). */
export interface ProxiedTokens {
  readonly model: string;
  readonly input: number;
  readonly output: number;
  readonly cacheCreate: number;
  readonly cacheCreate5m: number;
  readonly cacheCreate1h: number;
  readonly cacheRead: number;
}

/**
 * The write the model proxy makes before it forwards a request (DIPO-425): the agent's canonical
 * row of `model` made if missing and touched, so a database that cannot take writes refuses here,
 * before anything is spent.
 */
export function openProxiedRow(
  office: OfficeHandle,
  scope: UsageScope,
  model: string,
  at: number,
): void {
  const canonical = canonicalModel(model);
  ensureRow(office, scope, canonical, at);
  office.run(
    `update usage_totals set updated_at = $at
     where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
    { at, run: scope.run, agent: scope.agent, model: canonical },
  );
}

/** Adds one answer's tokens, as the model proxy read them, to the agent's canonical model row. */
export function recordProxiedUsage(
  office: OfficeHandle,
  scope: UsageScope,
  usage: ProxiedTokens,
  at: number,
): void {
  const model = canonicalModel(usage.model);
  ensureRow(office, scope, model, at);
  office.run(
    `update usage_totals set input = input + $input, output = output + $output,
       cache_create = cache_create + $create, cache_create_5m = cache_create_5m + $create5m,
       cache_create_1h = cache_create_1h + $create1h, cache_read = cache_read + $read,
       updated_at = $at
     where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
    {
      input: usage.input,
      output: usage.output,
      create: usage.cacheCreate,
      create5m: usage.cacheCreate5m,
      create1h: usage.cacheCreate1h,
      read: usage.cacheRead,
      at,
      run: scope.run,
      agent: scope.agent,
      model,
    },
  );
  setBudget(office, scope);
}

/**
 * The turn end of a session whose tokens the model proxy counts (DIPO-425): the turn count joins
 * the agent's canonical main model row and the live numbers end; no token changes.
 */
export function applyProxiedTurn(
  office: OfficeHandle,
  scope: UsageScope,
  turns: { readonly model: string; readonly count: number },
  at: number,
): void {
  const model = canonicalModel(turns.model);
  ensureRow(office, scope, model, at);
  office.run(
    `update usage_totals set turns = turns + $turns, updated_at = $at
     where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
    { turns: turns.count, at, run: scope.run, agent: scope.agent, model },
  );
  clearLiveUsage(office, scope.run, scope.agent);
}

/**
 * The cost the CLI reported at the turn end of a session whose tokens the model proxy counts
 * (DIPO-425): as `recordReportedCost`, its run-cumulative USD per model stored as reported, keyed
 * by the canonical model, so it sits on the row of the proxy's tokens.
 */
export function recordProxiedCost(
  office: OfficeHandle,
  scope: UsageScope,
  costUsd: Readonly<Record<string, number>>,
  at: number,
): void {
  const byModel = new Map<string, number>();
  for (const [model, dollars] of Object.entries(costUsd)) {
    const canonical = canonicalModel(model);
    byModel.set(canonical, (byModel.get(canonical) ?? 0) + dollars);
  }
  for (const [model, dollars] of byModel) {
    ensureRow(office, scope, model, at);
    office.run(
      `update usage_totals set cost_micros = $micros
       where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
      { micros: Math.round(dollars * 1_000_000), run: scope.run, agent: scope.agent, model },
    );
  }
}

function setBudget(office: OfficeHandle, scope: UsageScope): void {
  office.run(
    `update usage_totals set ${BUDGET_UPDATE}
     where office_id = $office_id and run_id = $run and agent_id = $agent`,
    { run: scope.run, agent: scope.agent },
  );
}

/**
 * The live numbers of the agent's turn in progress (DIPO-296): `turns` and `output` as the adapter
 * counts them since the last turn end, on the main model's row, every other row of the agent at 0.
 * For the live view only (see the file comment). Zeros always apply (the exit sends them); other
 * numbers never reach an agent whose totals are final (its run ended), so none stick after it.
 */
export function setLiveUsage(
  office: OfficeHandle,
  scope: UsageScope,
  model: string,
  live: { readonly turns: number; readonly output: number },
  at: number,
): void {
  if (live.turns <= 0 && live.output <= 0) {
    clearLiveUsage(office, scope.run, scope.agent);
    return;
  }
  const final = office.get(
    `select 1 as found from usage_totals
     where office_id = $office_id and run_id = $run and agent_id = $agent and final = 1`,
    { run: scope.run, agent: scope.agent },
  );
  if (final !== null) return;
  ensureRow(office, scope, model, at);
  office.run(
    `update usage_totals
       set live_turns = case when model = $model then $turns else 0 end,
         live_output = case when model = $model then $output else 0 end, updated_at = $at
     where office_id = $office_id and run_id = $run and agent_id = $agent`,
    {
      model,
      turns: Math.max(0, Math.round(live.turns)),
      output: Math.max(0, Math.round(live.output)),
      at,
      run: scope.run,
      agent: scope.agent,
    },
  );
}

/** Sets the live numbers of every row of the agent to 0, final or not (DIPO-296). */
function clearLiveUsage(office: OfficeHandle, run: string, agent: string): void {
  office.run(
    `update usage_totals set live_turns = 0, live_output = 0
     where office_id = $office_id and run_id = $run and agent_id = $agent
       and (live_turns <> 0 or live_output <> 0)`,
    { run, agent },
  );
}

/**
 * A turn end: the adapter's cumulative totals for this agent replace the live numbers of every
 * model, and the turn count joins the agent's main model row.
 */
export function applyTurnTotals(
  office: OfficeHandle,
  scope: UsageScope,
  totals: UsageTotalsByModel,
  turns: { readonly model: string; readonly count: number },
  at: number,
): void {
  for (const model of Object.keys(totals)) ensureRow(office, scope, model, at);
  ensureRow(office, scope, turns.model, at);
  const rows = office.all<{ model: string; cache_create_1h: number }>(
    `select model, cache_create_1h from usage_totals
     where office_id = $office_id and run_id = $run and agent_id = $agent`,
    { run: scope.run, agent: scope.agent },
  );
  // The 1 hour writes the messages reported, per canonical model (DIPO-89). A message names the
  // model as the API answered it (`claude-opus-5-5`), while the turn totals may key it with a
  // context marker (`claude-opus-5-5[1m]`); matched by exact id only, the split was lost and every
  // write was priced as a 5 minute write.
  const oneHour = new Map<string, number>();
  for (const row of rows) {
    const canonical = canonicalModel(row.model);
    oneHour.set(canonical, (oneHour.get(canonical) ?? 0) + row.cache_create_1h);
  }
  // The cache writes the totals report per canonical model, still to be given a 1 hour part.
  const createLeft = new Map<string, number>();
  for (const [model, usage] of Object.entries(totals)) {
    const canonical = canonicalModel(model);
    createLeft.set(canonical, (createLeft.get(canonical) ?? 0) + usage.cacheCreate);
  }
  for (const { model } of rows) {
    const usage = totals[model] ?? { input: 0, output: 0, cacheCreate: 0, cacheRead: 0 };
    const canonical = canonicalModel(model);
    const pool = oneHour.get(canonical) ?? 0;
    const writes = createLeft.get(canonical) ?? 0;
    // The 1 hour part is what messages reported, capped at the new total; 5 minute is the rest.
    // Keys of one canonical model share the pool in proportion to their cache writes; a row the
    // totals leave out has no writes and gets none.
    const create1h =
      writes === 0
        ? 0
        : Math.min(usage.cacheCreate, Math.round((pool * usage.cacheCreate) / writes));
    oneHour.set(canonical, pool - create1h);
    createLeft.set(canonical, writes - usage.cacheCreate);
    office.run(
      `update usage_totals set input = $input, output = $output, cache_create = $create,
         cache_create_1h = $create1h, cache_create_5m = $create - $create1h,
         cache_read = $read, turns = turns + $turns, live_turns = 0, live_output = 0,
         updated_at = $at
       where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
      {
        input: usage.input,
        output: usage.output,
        create: usage.cacheCreate,
        create1h,
        read: usage.cacheRead,
        turns: model === turns.model ? turns.count : 0,
        at,
        run: scope.run,
        agent: scope.agent,
        model,
      },
    );
  }
  setBudget(office, scope);
}

/**
 * The cost the worker CLI reported at a turn end (0008): its run-cumulative USD per model, stored
 * on the agent's rows in micro-USD as reported. A model the turn end leaves out keeps its cost.
 * Returns the models whose cost matched no usage row, for the caller to warn about.
 */
export function recordReportedCost(
  office: OfficeHandle,
  run: string,
  agent: string,
  costUsd: Readonly<Record<string, number>>,
): string[] {
  const missing: string[] = [];
  for (const [model, dollars] of Object.entries(costUsd)) {
    const updated = office.run(
      `update usage_totals set cost_micros = $micros
       where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
      { micros: Math.round(dollars * 1_000_000), run, agent, model },
    );
    if (updated.changes === 0) missing.push(model);
  }
  return missing;
}

/** Wall time of the agent, kept on its main model row. */
export function setElapsed(
  office: OfficeHandle,
  scope: UsageScope,
  model: string,
  elapsedMs: number,
  at: number,
): void {
  ensureRow(office, scope, model, at);
  office.run(
    `update usage_totals set elapsed_ms = $elapsed
     where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
    { elapsed: Math.max(0, elapsedMs), run: scope.run, agent: scope.agent, model },
  );
}

/** One `usage_totals` row as `usage_daily` is fed from it. */
export interface TotalsRow {
  run_id: string;
  model: string;
  role: string;
  tier: string;
  input: number;
  output: number;
  cache_create: number;
  cache_create_5m: number;
  cache_create_1h: number;
  cache_read: number;
  turns: number;
  elapsed_ms: number;
  budget_used: number;
  budget_limit: number;
  cost_micros: number | null;
}

/** `yyyy-mm-dd` in UTC. */
export function utcDay(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

/**
 * Marks the agent's totals final and feeds each row into `usage_daily` (0007: the
 * daily rollup has this one source). A row already final is never fed twice. Returns the number
 * of rows that became final.
 */
export function finalizeAgentUsage(
  office: OfficeHandle,
  run: string,
  agent: string,
  at: number,
): number {
  const rows = office.all<TotalsRow>(
    `select run_id, model, role, tier, input, output, cache_create, cache_create_5m,
       cache_create_1h, cache_read, turns, elapsed_ms,
       budget_used, budget_limit, cost_micros
     from usage_totals
     where office_id = $office_id and run_id = $run and agent_id = $agent and final = 0`,
    { run, agent },
  );
  // The live numbers of a turn that never ended go, also on rows final already (DIPO-296).
  clearLiveUsage(office, run, agent);
  const day = utcDay(at);
  for (const row of rows) {
    // A run counts once per day, role, tier and model, however many agents it had.
    const counted = office.get(
      `select 1 as found from usage_totals
       where office_id = $office_id and run_id = $run and final = 1 and role = $role
         and tier = $tier and model = $model`,
      { run: row.run_id, role: row.role, tier: row.tier, model: row.model },
    );
    const newRun = counted === null ? 1 : 0;
    office.run(
      `update usage_totals set final = 1, updated_at = $at
       where office_id = $office_id and run_id = $run and agent_id = $agent and model = $model`,
      { at, run, agent, model: row.model },
    );
    office.run(
      `insert into usage_daily (office_id, day, role, tier, model, input, output, cache_create,
         cache_create_5m, cache_create_1h, cache_read, turns, runs, cost_micros, budget_used,
         budget_limit_sum)
       values ($office_id, $day, $role, $tier, $model, $input, $output, $create, $create5m,
         $create1h, $read, $turns,
         $runs, $cost, $used, $limit)
       on conflict (office_id, day, role, tier, model) do update set
         input = input + excluded.input,
         output = output + excluded.output,
         cache_create = cache_create + excluded.cache_create,
         cache_create_5m = cache_create_5m + excluded.cache_create_5m,
         cache_create_1h = cache_create_1h + excluded.cache_create_1h,
         cache_read = cache_read + excluded.cache_read,
         turns = turns + excluded.turns,
         runs = runs + excluded.runs,
         cost_micros = case
           when excluded.cost_micros is null then cost_micros
           else coalesce(cost_micros, 0) + excluded.cost_micros end,
         budget_used = budget_used + excluded.budget_used,
         budget_limit_sum = budget_limit_sum + excluded.budget_limit_sum`,
      {
        day,
        role: row.role,
        tier: row.tier,
        model: row.model,
        input: row.input,
        output: row.output,
        create: row.cache_create,
        create5m: row.cache_create_5m,
        create1h: row.cache_create_1h,
        read: row.cache_read,
        turns: row.turns,
        runs: newRun,
        cost: row.cost_micros,
        used: row.budget_used,
        limit: newRun === 1 ? row.budget_limit : 0,
      },
    );
  }
  return rows.length;
}

/** The sums `readUsage` shows: turns and output with the live numbers of a turn in progress. */
const SUMS = `coalesce(sum(input), 0) as input,
  coalesce(sum(output + live_output), 0) as output,
  coalesce(sum(cache_create), 0) as cache_create, coalesce(sum(cache_read), 0) as cache_read,
  coalesce(sum(turns + live_turns), 0) as turns, coalesce(sum(elapsed_ms), 0) as elapsed_ms`;

interface SumRow {
  input: number;
  output: number;
  cache_create: number;
  cache_read: number;
  turns: number;
  elapsed_ms: number;
}

function toTotals(row: SumRow | null): UsageTotals {
  return {
    inputTokens: row?.input ?? 0,
    outputTokens: row?.output ?? 0,
    cacheCreateTokens: row?.cache_create ?? 0,
    cacheReadTokens: row?.cache_read ?? 0,
    turns: row?.turns ?? 0,
    elapsedMs: row?.elapsed_ms ?? 0,
  };
}

/** The contract `Usage` of an agent within its run (0005). */
export function readUsage(office: OfficeHandle, scope: UsageScope): Usage {
  const agent = toTotals(
    office.get<SumRow>(
      `select ${SUMS} from usage_totals
       where office_id = $office_id and run_id = $run and agent_id = $agent`,
      { run: scope.run, agent: scope.agent },
    ),
  );
  const run = toTotals(
    office.get<SumRow>(
      `select ${SUMS} from usage_totals where office_id = $office_id and run_id = $run`,
      { run: scope.run },
    ),
  );
  // Includes the live output of a turn in progress (DIPO-296): the view shows the spend so far,
  // while the caps count output only at the turn end (0008), so a session may show more
  // of its budget used than the cap check has counted yet. A reviewer counts against its own caps
  // (0002): its budget is its own session's usage, and the story's budget leaves reviewers out.
  const counted =
    scope.role === REVIEWER_ROLE
      ? agent
      : toTotals(
          office.get<SumRow>(
            `select ${SUMS} from usage_totals where office_id = $office_id and run_id = $run
              and role is not $reviewer`,
            { run: scope.run, reviewer: REVIEWER_ROLE },
          ),
        );
  const used = counted.inputTokens + counted.outputTokens + counted.cacheCreateTokens;
  const limit = Math.max(0, scope.budgetLimit);
  return {
    agent,
    run,
    budget: { unit: "tokens", limit, used },
    budgetShare: limit > 0 ? used / limit : 0,
  };
}

/**
 * One context compaction of the worker session (0008, DIPO-106). `preTokens` is null when
 * the adapter had no count for it.
 */
export function recordCompaction(
  office: OfficeHandle,
  scope: UsageScope,
  preTokens: number | null,
  at: number,
): void {
  office.run(
    `insert into compactions (office_id, seq, run_id, agent_id, pre_tokens, at)
     values ($office_id, (select coalesce(max(seq), 0) + 1 from compactions
       where office_id = $office_id), $run, $agent, $preTokens, $at)`,
    { run: scope.run, agent: scope.agent, preTokens, at },
  );
}

/** The compaction count and the latest compaction's pre-compaction tokens (DIPO-106). */
export interface CompactionStat {
  readonly count: number;
  /** Null when no compaction was stored, or when the latest one had no count. */
  readonly latestPreTokens: number | null;
}

interface CompactionRow {
  count: number;
  pre_tokens: number | null;
}

/** The compactions of the agent, and of the run, as stored (DIPO-106). */
export function readCompactions(
  office: OfficeHandle,
  scope: UsageScope,
): { readonly agent: CompactionStat; readonly run: CompactionStat } {
  const stat = (where: string, params: Record<string, string>): CompactionStat => {
    const count = office.get<CompactionRow>(
      `select count(*) as count, (select pre_tokens from compactions
          where office_id = $office_id and ${where}
          order by seq desc limit 1) as pre_tokens
        from compactions where office_id = $office_id and ${where}`,
      params,
    );
    return { count: count?.count ?? 0, latestPreTokens: count?.pre_tokens ?? null };
  };
  return {
    agent: stat("run_id = $run and agent_id = $agent", { run: scope.run, agent: scope.agent }),
    run: stat("run_id = $run", { run: scope.run }),
  };
}

/** An agent's `usage_totals` rows that are final, by model (DIPO-51). */
export type FinalRows = ReadonlyMap<string, TotalsRow>;

/** The agent's final rows now, by model; read before a change, for `feedFinalChanges`. */
export function finalRows(office: OfficeHandle, run: string, agent: string): FinalRows {
  const rows = office.all<TotalsRow>(
    `select run_id, model, role, tier, input, output, cache_create, cache_create_5m,
       cache_create_1h, cache_read, turns, elapsed_ms,
       budget_used, budget_limit, cost_micros
     from usage_totals
     where office_id = $office_id and run_id = $run and agent_id = $agent and final = 1`,
    { run, agent },
  );
  return new Map(rows.map((row) => [row.model, row]));
}

/**
 * Usage ingested after the run ended (0007): a run usually ends
 * before its worker's exit is ingested, so `endRun` made the agent's rows final. What ingestion
 * changed since `before` in a row that was already final feeds only its change into
 * `usage_daily`, in the caller's transaction, and a new row of such an agent becomes final at
 * once. So `usage_daily` stays the sum of final rows: nothing counted twice or lost.
 */
export function feedFinalChanges(
  office: OfficeHandle,
  run: string,
  agent: string,
  before: FinalRows,
  at: number,
): void {
  if (before.size === 0) return;
  const day = utcDay(at);
  for (const [model, row] of finalRows(office, run, agent)) {
    const old = before.get(model);
    if (old === undefined) continue;
    const change = {
      input: row.input - old.input,
      output: row.output - old.output,
      create: row.cache_create - old.cache_create,
      create5m: row.cache_create_5m - old.cache_create_5m,
      create1h: row.cache_create_1h - old.cache_create_1h,
      read: row.cache_read - old.cache_read,
      turns: row.turns - old.turns,
      used: row.budget_used - old.budget_used,
      cost: row.cost_micros === null ? null : row.cost_micros - (old.cost_micros ?? 0),
    };
    const moved = Object.values(change).some((value) => value !== null && value !== 0);
    if (!moved) continue;
    office.run(
      `insert into usage_daily (office_id, day, role, tier, model, input, output, cache_create,
         cache_create_5m, cache_create_1h, cache_read, turns, runs, cost_micros, budget_used,
         budget_limit_sum)
       values ($office_id, $day, $role, $tier, $model, $input, $output, $create, $create5m,
         $create1h, $read, $turns, 0, $cost, $used, 0)
       on conflict (office_id, day, role, tier, model) do update set
         input = input + excluded.input,
         output = output + excluded.output,
         cache_create = cache_create + excluded.cache_create,
         cache_create_5m = cache_create_5m + excluded.cache_create_5m,
         cache_create_1h = cache_create_1h + excluded.cache_create_1h,
         cache_read = cache_read + excluded.cache_read,
         turns = turns + excluded.turns,
         cost_micros = case
           when excluded.cost_micros is null then cost_micros
           else coalesce(cost_micros, 0) + excluded.cost_micros end,
         budget_used = budget_used + excluded.budget_used`,
      { day, role: row.role, tier: row.tier, model, ...change },
    );
  }
  // A model first seen after the end: its row is final from the start.
  finalizeAgentUsage(office, run, agent, at);
}

/**
 * Makes the usage of every agent of the run whose exit was not ingested final, so it reaches
 * `usage_daily` (0007). `endRun` calls it in its transaction.
 */
export function finalizeRunAgents(office: OfficeHandle, run: string, at: number): void {
  const agents = office.all<{ agent_id: string }>(
    `select distinct t.agent_id from usage_totals t
      where t.office_id = $office_id and t.run_id = $run and t.final = 0
        and not exists (select 1 from ingest_cursors c
          where c.office_id = t.office_id and c.run_id = t.run_id and c.agent_id = t.agent_id
            and c.source_kind = 'host-events' and c.ended_at is not null)
      order by t.agent_id`,
    { run },
  );
  for (const { agent_id: agent } of agents) finalizeAgentUsage(office, run, agent, at);
}

/**
 * True when the agent's context nears full (DIPO-448): its session compacted, or the tokens it
 * counted, input plus output plus cache creation, reach `limit`. The counted tokens are the new
 * content its context took in, so they stand in for the context's size.
 */
export function contextNearFull(office: OfficeHandle, scope: UsageScope, limit: number): boolean {
  if (readCompactions(office, scope).agent.count > 0) return true;
  const { agent } = readUsage(office, scope);
  return agent.inputTokens + agent.outputTokens + agent.cacheCreateTokens >= limit;
}
