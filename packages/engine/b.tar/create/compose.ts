// The one wiring of the run services (DIPO-129): ingestion with the web call counts, `work.answer`
// (`QuestionAnswers`), run control, worker outcomes, the resumer, the office's starts paused, the office's session
// places (DIPO-142) with the pending reviews and their starter (DIPO-219), the fix rounds and
// their starter (DIPO-148), the launcher and re-attach, built from injected ports. The daemon and
// the engine's run tests both build them here, so a test exercises the wiring the daemon runs.
// What differs between them is only which ports are injected.

import type { Clock, IdSource, OfficeId, RunId } from "@dipsaus-orchestrator/contract";

import type { BoxWorkers } from "../box/workers";

import { QuestionAnswers } from "../questions/answers";
import { OFFICE_DEFAULTS } from "../config";
import { CONTRACT_MAX_DEFAULT } from "../prompts/contract";
import { currentProfile } from "../scan/store";
import type { RunProfile } from "../scan/detect";
import type { WorkerPort } from "../workers/port";
import { RunControl, type RunControlDeps, type RunSteering } from "../run/control";
import { OfficeIngest, type OfficeIngestOptions, type OfficeRunListener } from "../run/hosts";
import { RunLauncher, type HostStarter, type RunIngest, type RunLauncherDeps } from "../run/launch";
import type { RunOutcomes, RunOutcomesDeps, RunOutcomesPort } from "../run/outcomes";
import { Places, type PlacesDeps } from "../run-state/places";
import { RunReattacher, type RunReattacherDeps } from "../run/reattach";
import type { SignalProcess } from "../platform/process";
import { baseStoryFacts, RunResumer, type RunResumerDeps } from "../run/resume";
import { gitReviewOps, ReviewLauncher } from "../run/review-launch";
import { FixRounds, type FixRoundsDeps } from "../run/fix-rounds";
import { Reviews } from "../run/reviews";
import { createRunOutcomes, type Resumption } from "../run/resumption";
import { SessionRuns } from "../run/session-run";
import { AuditSessions } from "../run/audit-session";
import { IdeaAudits } from "../run/idea-audits";
import { StartsPaused, type StartsPausedDeps } from "../run/starts-paused";
import { afterRunExits } from "../run/temp-dirs";
import { WebCalls } from "../run/web-calls";
import { BaseCatchUps, type BaseCatchUpsDeps } from "../run/base-merges";
import { ConflictResumes, type ConflictResumesDeps } from "../run/conflicts";
import type { OfficeHandle } from "../db/office";
import { findRun, type StoredRun } from "../records/run-records";
import { resolveIntent, runIntents } from "../records/intents";
import type { MergeReentry, PrReplacement } from "../run/park-resume";
import type { StoryStore } from "../story-store/store";
import type { ParkStore } from "../records/park-state";
import { workRefOf } from "../views/work";
import { PlanningSessions, type PlanningSessionsDeps } from "../run/planning-session";
import type { HoldResumer } from "../run/work-resume";
import { Partner } from "../wiring/partner";
import type { RunBase } from "../run/work-run";

type Warn = (message: string, fields: Readonly<Record<string, unknown>>) => void;

export interface RunPorts {
  /** The story store: the park a pending planning change writes (`plannedPark`, 0010). */
  readonly stories: ParkStore & Pick<StoryStore, "storyFolders">;
  readonly clock: Clock;
  readonly ids: IdSource;
  readonly offices: RunResumerDeps["offices"];
  readonly worker: WorkerPort;
  /** Sends host ops to a running worker (`hostSocketSteering` in the daemon). */
  readonly steering: RunSteering;
  readonly hosts: HostStarter;
  readonly git: RunLauncherDeps["git"];
  /** The stories on the base: a launch's dependencies and a next session's story (DIPO-51). */
  readonly base: Pick<RunBase, "read">;
  readonly runtimeDir: string;
  readonly tmpRoot: string;
  readonly tempOwner?: () => string | undefined;
  readonly onChanged?: (office: Parameters<NonNullable<RunControlDeps["onChanged"]>>[0]) => void;
  readonly warn?: Warn;
  readonly refreshStory?: RunControlDeps["refreshStory"];
  /** Ends a live claim whose worker did not start; the launcher's and the outcomes' release. */
  readonly release: RunLauncherDeps["release"];
  /** Runs after each worker exit decision of worker outcomes (the run temp directory sweep). */
  readonly afterExit?: () => void;
  /**
   * Runs before each developer exit, or host found dead, is decided (DIPO-376): the box workers
   * keep what Safe-Chain refused in the session (`BoxWorkers.sessionEnded`), so the run's next
   * session is told. Never rejects.
   */
  readonly beforeExit?: (runId: string) => Promise<void>;
  /** False while no work is scheduled: the office's starts paused. */
  readonly scheduling?: () => boolean;
  /** Ingestion; every entry it appends reaches `onChanged` at once. */
  readonly ingest: Pick<OfficeIngestOptions, "watchdog"> & {
    /** Hears each run's worker exit. */
    readonly onEnded?: OfficeRunListener["onEnded"];
  };
  /** Run control; without it nothing is tracked, ended or decided (and no outcomes follow). */
  readonly control?: Pick<RunControlDeps, "writer" | "finisher" | "implemented" | "tickMs">;
  /** Worker outcomes and the run's next session; needs `control`. */
  readonly outcomes?: Pick<RunOutcomesDeps, "holds" | "holdsWork" | "caps" | "unpark"> & {
    /** The liveness of earlier hosts a next session waits for (DIPO-57). */
    readonly probe?: RunResumerDeps["probe"];
    /** With `probe`: one verified SIGTERM to a host still alive for a parked run (DIPO-411). */
    readonly signal?: SignalProcess;
  };
  /** The planning lane's resume of a park with no run (DIPO-160), read when `work.resume` runs. */
  readonly holdResumer?: () => HoldResumer | undefined;
  /** The auto-merge a story resumed to wait In Review goes back to (0002). */
  readonly mergeReentry?: () => MergeReentry | undefined;
  /**
   * The story store a merge of the base outside the box finds the story's own file with: the
   * resume of a `conflict` park (DIPO-324) and the merge of a moved base before a resumed or fix
   * round session and at a story In Review (`BaseCatchUps`, DIPO-464). Without it no conflict park
   * resumes (`resume.notResumable`) and no base is merged outside the box.
   */
  readonly conflictResume?: Pick<ConflictResumesDeps, "stories">;
  /** The new story PR of a story resumed with its PR closed (`StoryPrs.replace`, 0002). */
  readonly prReplacement?: () => PrReplacement | undefined;
  /**
   * The office's starts paused (0020): the loaded offices a plan limit pauses together and the
   * adapter holds of a failed adapter check; needs `outcomes`.
   */
  readonly startsPaused?: Pick<StartsPausedDeps, "loaded" | "holds" | "adapter">;
  /** The office's run slots (DIPO-142): its pending reviews and the runs waiting for one. */
  readonly places?: Pick<PlacesDeps, "pending" | "reviewing">;
  /**
   * Where the CI of a run's pushed head stands (`StoryPrs.ciState`, DIPO-147): a fix round waits
   * for its checks (DIPO-148). Without it no CI is waited for.
   */
  readonly ci?: FixRoundsDeps["ci"];
  /** Replaces run control as the resumer's and the launcher's tracker (a test's caps override). */
  readonly tracker?: (control: RunControl) => NonNullable<RunLauncherDeps["control"]>;
  /** Replaces ingestion as the resumer's (a test recording each start). */
  readonly resumeIngest?: (ingest: OfficeIngest) => RunIngest;

  /**
   * The box workers (DIPO-271, DIPO-278): every developer works in its story's box, made at the
   * launch and made again before a later session when it was lost. No box runs without them.
   */
  readonly boxes?: RunLauncherDeps["boxes"];
  /** The reviewer boxes (0002): each review session runs in one. No reviewer runs without them. */
  readonly reviewBoxes?: Pick<BoxWorkers, "review" | "endReview">;
  /** The planning boxes (DIPO-447): each planning session runs in one. None runs without them. */
  readonly planningBoxes?: Pick<BoxWorkers, "planning" | "endPlanning">;
  /** The office's desk, for a planning session's first message (DIPO-447). */
  readonly planningDesk?: PlanningSessionsDeps["desk"];
  /** The office's planning lane, which files what the maintainer confirms (DIPO-450). */
  readonly planningLane?: PlanningSessionsDeps["lane"];
  /** The office's Ready gate, for a planning session's final confirm (DIPO-451). */
  readonly planningGate?: PlanningSessionsDeps["gate"];
  /**
   * Copies into a run's box the merges dipo committed on its branch outside the box, before its
   * next developer session (DIPO-324); a failure parks the story instead of starting the worker.
   */
  readonly boxSync?: RunResumerDeps["boxSync"];
  /**
   * Takes what a run's box holds since its last part as a part, before a merge of a moved base is
   * copied into it (DIPO-464, `BaseCatchUpsDeps.takePart`). Without it no part is taken first.
   */
  readonly boxPart?: BaseCatchUpsDeps["takePart"];
  /** Re-attach after a restart; needs `control`. */
  readonly reattach?: Omit<
    RunReattacherDeps,
    "clock" | "offices" | "ingest" | "control" | "outcomes" | "onChanged" | "warn"
  >;
}

export interface ComposedRuns {
  readonly ingest: OfficeIngest;
  /** `work.answer` on the question a park carries (0020). */
  readonly answers: QuestionAnswers;
  readonly control: RunControl | null;
  readonly outcomes: RunOutcomes | null;
  /** Park resume and `work.resume` (DIPO-138), sharing the outcomes' facts. */
  readonly resumption: Resumption | null;
  readonly resumer: RunResumer | null;
  /** The office's starts paused (0020); needs `outcomes` and the `startsPaused` port. */
  readonly startsPaused: StartsPaused | null;
  /** The run slots with their start order (DIPO-142); needs `outcomes`. */
  readonly places: Places | null;
  /** The review rounds (DIPO-219): pending reviews, their starter and the reviewer's outcomes. */
  readonly reviews: Reviews | null;
  /**
   * The fix rounds (DIPO-148): review and CI feedback on a pushed head back to its worker, once per
   * head; `consider` is to be called when the CI of a head stops being pending.
   */
  readonly fixRounds: FixRounds | null;
  /**
   * A story In Review that the collision poll found conflicting with the base (DIPO-464): the
   * base merged outside the box and the conflict handed to its worker as one fix round at once.
   * Null without the story store port of a merge outside the box.
   */
  readonly inReviewConflict: ((office: OfficeId, runId: RunId) => Promise<void>) | null;
  readonly launcher: RunLauncher;
  readonly reattacher: RunReattacher | null;
  /**
   * The scan fallback's `session` runs (DIPO-310): one model session outside a story, on the same
   * worker port, hosts and steering as the story runs, outside the worker and reviewer places.
   */
  readonly sessions: SessionRuns;
  /**
   * The maintainer's planning sessions (DIPO-447): one per office at most, in a read-only box,
   * on the same worker port, hosts and steering, holding no run slot.
   */
  readonly planning: PlanningSessions;
  /**
   * The audit of incoming ideas (DIPO-452): code first, then one audit session per batch, each in
   * a planning box of its own, holding no run slot and not the planning session.
   */
  readonly audits: IdeaAudits;
  readonly auditSessions: AuditSessions;
}

/** `{ [key]: value }`, or `{}` when `value` is undefined (an optional port left out). */
function given<K extends string, V>(key: K, value: V | undefined): { [P in K]?: V } {
  return value === undefined ? {} : ({ [key]: value } as { [P in K]?: V });
}

/**
 * The run services that call a service built after them (DIPO-318). Each is connected once, in
 * `connectRunPartners`, right after every service exists; a call before that throws. A partner
 * connected to null is a service these ports leave out.
 */
interface RunPartners {
  readonly ingest: Partner<OfficeIngest>;
  readonly resumption: Partner<Resumption | null>;
  readonly exitPort: Partner<RunOutcomesPort | null>;
  readonly startsPaused: Partner<StartsPaused | null>;
  readonly places: Partner<Places | null>;
  readonly fixRounds: Partner<FixRounds | null>;
}

function runPartners(): RunPartners {
  return {
    ingest: new Partner("run ingestion"),
    resumption: new Partner("the resumption"),
    exitPort: new Partner("the exit decisions"),
    startsPaused: new Partner("the office's starts paused"),
    places: new Partner("the places"),
    fixRounds: new Partner("the fix rounds"),
  };
}

function buildControl(ports: RunPorts, partners: RunPartners): RunControl | null {
  if (ports.control === undefined) return null;
  return new RunControl({
    ...ports.control,
    stories: ports.stories,
    clock: ports.clock,
    offices: ports.offices,
    ids: ports.ids,
    steering: ports.steering,
    encode: (op) => ports.worker.encode(op),
    // The ingestion hooks call the control, and the control flushes ingestion's output first.
    flushOutput: (office, run) => partners.ingest.get().flushOutput(office, run),
    // Each exit decision may end the run after its worker exited (the temp directory goes).
    outcomes: () => partners.exitPort.get() ?? undefined,
    // A park to resume on lift that lands while the office is not paused resumes then (0020).
    parkedToResume: (office) => partners.startsPaused.get()?.resumeLifted(office),
    ...given("onChanged", ports.onChanged),
    ...given("refreshStory", ports.refreshStory),
    ...given("warn", ports.warn),
  });
}

interface RunListeners {
  readonly answers: QuestionAnswers;
  readonly webCalls: WebCalls;
  readonly runEvents: OfficeRunListener;
}

/** `work.answer` and the web calls, and the one listener per ingestion pass. */
function buildRunListeners(ports: RunPorts, partners: RunPartners): RunListeners {
  const answers = new QuestionAnswers({
    stories: ports.stories,
    clock: ports.clock,
    // An answer to a question park resumes it through work.resume's park path (DIPO-159).
    questionParks: () => partners.resumption.get()?.questionParks,
    ...given("onChanged", ports.onChanged),
  });
  const webCalls = new WebCalls({
    offices: ports.offices,
    checkout: (office) => ports.git(office)?.mainWorktree,
    ...given("warn", ports.warn),
  });
  const onEnded = ports.ingest.onEnded;
  const runEvents: OfficeRunListener = {
    onWorkerEvents: (office, run, agent, events) => {
      webCalls.onWorkerEvents(office, run, agent, events);
    },
    onEnded: (office, run) => {
      onEnded?.(office, run);
    },
  };
  return { answers, webCalls, runEvents };
}

function buildIngest(
  ports: RunPorts,
  control: RunControl | null,
  listeners: Pick<RunListeners, "runEvents" | "webCalls">,
): OfficeIngest {
  const { runEvents, webCalls } = listeners;
  return new OfficeIngest({
    clock: ports.clock,
    ...(control === null ? {} : { hooks: control.hooks }),
    runEvents,
    // No env value of the listed files reaches the stored web lines (0020, DIPO-164).
    redactOutput: (office, run, text) => webCalls.redactOutput(office, run, text),
    ...given("watchdog", ports.ingest.watchdog),
    ...given("onAppended", ports.onChanged),
    // `privacy.storeCommandBodies` of the configuration in force (0007, DIPO-83).
    privacy: (office) => ({
      storeCommandBodies: ports.offices.config(office)?.privacy.storeCommandBodies ?? false,
    }),
    ...given("warn", ports.warn),
  });
}

/** Run control as the resumer and the launcher track runs with it (or the test's override). */
function trackerOf(ports: RunPorts, control: RunControl): NonNullable<RunLauncherDeps["control"]> {
  return ports.tracker?.(control) ?? control;
}

interface Outcomes {
  readonly resumer: RunResumer;
  readonly outcomes: RunOutcomes;
  readonly resumption: Resumption;
  readonly startsPaused: StartsPaused | null;
  readonly places: Places;
  readonly reviews: Reviews;
  readonly fixRounds: FixRounds;
  readonly inReviewConflict: ((office: OfficeId, runId: RunId) => Promise<void>) | null;
}

/**
 * The resumer, worker outcomes, the office's starts paused and the places; null without control or
 * outcomes.
 */
function buildOutcomes(
  ports: RunPorts,
  control: RunControl | null,
  ingest: OfficeIngest,
  partners: RunPartners,
): Outcomes | null {
  if (control === null || ports.outcomes === undefined) return null;
  const { probe, signal, ...outcomePorts } = ports.outcomes;
  const baseMerges = baseCatchUpsOf(ports);
  const resumer = new RunResumer({
    stories: ports.stories,
    clock: ports.clock,
    ids: ports.ids,
    offices: ports.offices,
    worker: ports.worker,
    git: ports.git,
    story: baseStoryFacts(ports.base),
    runtimeDir: ports.runtimeDir,
    tmpRoot: ports.tmpRoot,
    hosts: ports.hosts,
    ingest: ports.resumeIngest?.(ingest) ?? ingest,
    control: trackerOf(ports, control),
    ...given("boxes", ports.boxes),
    ...given("boxSync", ports.boxSync),
    // A resumed or fix round session gets a base that moved merged first (DIPO-464).
    ...given(
      "catchUp",
      baseMerges === null
        ? undefined
        : (office: OfficeId, run: StoredRun) => baseMerges.beforeSession(office, run),
    ),
    profile: profileOf(ports),
    ...given("probe", probe),
    ...given("onChanged", ports.onChanged),
  });
  const { outcomes, resumption } = createRunOutcomes(
    {
      ...outcomePorts,
      startsPaused: () => partners.startsPaused.get() ?? undefined,
      stories: ports.stories,
      clock: ports.clock,
      offices: ports.offices,
      steering: ports.steering,
      encode: (op) => ports.worker.encode(op),
      worker: ports.worker,
      ender: () => control,
      resumer,
      release: ports.release,
      ...given("refreshStory", ports.refreshStory),
      ...given("onChanged", ports.onChanged),
      ...given("warn", ports.warn),
    },
    {
      places: () => partners.places.get() ?? undefined,
      ...given("holds", ports.holdResumer),
      parks: {
        ...given("scheduling", ports.scheduling),
        // Built after the resumption: a resumed review-blocked park queues its fix round (DIPO-155).
        fixRounds: () => partners.fixRounds.get() ?? undefined,
        ...given("merge", ports.mergeReentry),
        // A conflict park resumes through the hand-off of its box run (DIPO-324).
        ...given("conflicts", conflictResumesOf(ports, control)),
        ...given("prs", ports.prReplacement),
        // A question park's answer is a resolved unknown while the contract stays within R26.
        contractMax: (office) =>
          ports.offices.config(office)?.prompt.contractMax ?? CONTRACT_MAX_DEFAULT,
        // No resume while the office's starts are paused (0020).
        startsPaused: (office) => partners.startsPaused.get()?.state(office) ?? null,
        // A host still alive for the parked run gets one verified SIGTERM (DIPO-411).
        ...given(
          "hostSignals",
          probe === undefined || signal === undefined ? undefined : { probe, signal },
        ),
      },
    },
  );
  // A plan limit pauses the office's starts; its lift resumes the parks it made through the
  // resumption and starts what waited for a place (0020).
  const startsPaused =
    ports.startsPaused === undefined
      ? null
      : new StartsPaused({
          ...ports.startsPaused,
          clock: ports.clock,
          offices: ports.offices,
          resume: (office, park) => resumption.resumeLifted(office, park),
          onLifted: (office) => void partners.places.get()?.drain(office),
          ...given("scheduling", ports.scheduling),
          ...given("onChanged", ports.onChanged),
          ...given("warn", ports.warn),
        });
  // A fix round continues the developer's session through worker outcomes (DIPO-148).
  const fixRounds = new FixRounds({
    stories: ports.stories,
    clock: ports.clock,
    offices: ports.offices,
    story: baseStoryFacts(ports.base),
    ...given("ci", ports.ci),
    sessions: outcomes.parts.sessions,
    view: (officeId, office, run) => outcomes.parts.support.viewOf(officeId, office, run),
    ...given("unpark", outcomePorts.unpark),
    places: () => partners.places.get() ?? undefined,
    guard: outcomes.parts.support.guard,
    // A round that cannot start and will not on its own parks the story (DIPO-148).
    park: (office, run, work, ending) => control.park(office, run, work, ending),
    // A verdict on another commit holds for a head with the same code tree (0002).
    treeKey: (office, run, taskFile, head) =>
      gitReviewOps(ports.git).codeTreeKey(office, taskFile, head),
    ...given("refreshStory", ports.refreshStory),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
  const reviews = buildReviews(ports, control, ingest, startsPaused, fixRounds);
  // The places wait while the office's starts are paused, start a queued resume through the
  // resumption and a pending review through the review rounds, up to the office's limit (0002).
  const places = new Places({
    ...ports.places,
    clock: ports.clock,
    offices: ports.offices,
    pending: ports.places?.pending ?? ((office) => reviews.pending(office)),
    reviewing: ports.places?.reviewing ?? ((office) => reviews.reviewing(office)),
    limit: (office) =>
      ports.offices.config(office)?.caps.parallelRuns ?? OFFICE_DEFAULTS.caps.parallelRuns,
    ...(startsPaused === null
      ? {}
      : {
          startsPaused: (office: OfficeId) => {
            const paused = startsPaused.state(office);
            return paused === null ? null : `the office's starts are paused (${paused.detail})`;
          },
        }),
    park: (office, run, work, ending) => control.park(office, run, work, ending),
    starters: {
      resume: (office, run) => resumption.startQueued(office, run),
      review: (office, run, start) => reviews.start(office, run, start),
      // A maintainer resume that starts a fresh review of the same round (0020, DIPO-155).
      "review-resume": (office, run, start) => reviews.start(office, run, start),
      fix: (office, run, start) => fixRounds.start(office, run, start),
    },
    ...given("scheduling", ports.scheduling),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
  // A story In Review whose branch conflicts with the base: merged and handed off at once (DIPO-464).
  const inReviewConflict =
    baseMerges === null ? null : inReviewConflictOf(ports, control, baseMerges, fixRounds);
  return {
    resumer,
    outcomes,
    resumption,
    startsPaused,
    places,
    reviews,
    fixRounds,
    inReviewConflict,
  };
}

/** The status a merge that took the other side's task file writes back: In Progress. */
function restoreStatusOf(ports: RunPorts): (office: OfficeId, run: StoredRun) => Promise<void> {
  return async (office, run) => {
    const unpark = ports.outcomes?.unpark;
    if (unpark === undefined || run.story === null || run.branch === null) return;
    await unpark.lift(office, {
      story: run.story,
      branch: run.branch,
      to: "In Progress",
    });
  };
}

/** The conflict item's character budget of the run's tier (`prompt.budgets.feedbackItem`). */
function itemMaxOf(ports: RunPorts): (office: OfficeId, run: StoredRun) => number {
  return (office, run) => {
    const budgets = ports.offices.config(office)?.prompt.budgets.feedbackItem;
    if (budgets === undefined) return 3_000;
    const tier = run.tier as keyof typeof budgets | null;
    return (tier === null ? undefined : budgets[tier]) ?? budgets.M;
  };
}

/** Parks a run with no worker running, and resolves the park's intent, which no worker will. */
function parkIdleOf(
  ports: RunPorts,
  control: RunControl,
): (
  office: OfficeHandle,
  run: StoredRun,
  park: { readonly reason: "conflict"; readonly detail: string },
) => Promise<void> {
  return async (office, run, park) => {
    await control.park(office, run, workRefOf(office, run.runId) ?? undefined, {
      intent: "park",
      ops: [],
      reason: park.reason,
      detail: park.detail,
    });
    const intent = runIntents(office, run.runId)
      .filter((candidate) => candidate.kind === "park" && candidate.resolvedAt === null)
      .at(-1);
    if (intent !== undefined) {
      const at = ports.clock.now();
      office.immediate(() => resolveIntent(office, run.runId, intent.intentId, "blocked", at));
    }
  };
}

/** The merges of a moved base outside the box (DIPO-464); null without the story store port. */
function baseCatchUpsOf(ports: RunPorts): BaseCatchUps | null {
  const conflict = ports.conflictResume;
  if (conflict === undefined) return null;
  return new BaseCatchUps({
    stories: conflict.stories,
    clock: ports.clock,
    offices: ports.offices,
    git: ports.git,
    tmpRoot: ports.tmpRoot,
    restoreStatus: restoreStatusOf(ports),
    itemMax: itemMaxOf(ports),
    // The box's work is taken as a part before a merge is copied into it (DIPO-464).
    ...given("takePart", ports.boxPart),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
}

/**
 * A story In Review that the collision poll found conflicting with the base (DIPO-464): the base
 * merged and the conflict handed to the worker as one fix round, or the story parked `conflict`.
 */
function inReviewConflictOf(
  ports: RunPorts,
  control: RunControl,
  baseMerges: BaseCatchUps,
  fixRounds: FixRounds,
): (office: OfficeId, runId: RunId) => Promise<void> {
  const parkIdle = parkIdleOf(ports, control);
  return async (officeId, runId) => {
    const office = ports.offices.get(officeId);
    const run = office === undefined ? null : findRun(office, runId);
    if (office === undefined || run === null) return;
    const merge = await baseMerges.inReview(officeId, run);
    if (merge.kind === "park") {
      await parkIdle(office, run, { reason: "conflict", detail: merge.detail });
      return;
    }
    if (merge.kind !== "handOff") return;
    const queued = await fixRounds.conflict(officeId, runId, {
      head: merge.head,
      item: merge.item,
    });
    if (!queued) ports.warn?.("the conflict of a story In Review was not handed over", { runId });
  };
}

/**
 * The resume of a `conflict` park (DIPO-324): the office git and its story store, and run control
 * to park it again. Undefined without the story store port.
 */
function conflictResumesOf(
  ports: RunPorts,
  control: RunControl,
): (() => ConflictResumes) | undefined {
  const conflict = ports.conflictResume;
  if (conflict === undefined) return undefined;
  const resumes = new ConflictResumes({
    stories: conflict.stories,
    clock: ports.clock,
    offices: ports.offices,
    git: ports.git,
    tmpRoot: ports.tmpRoot,
    // A merge that took the other side's task file gets the story's status back (In Progress).
    restoreStatus: restoreStatusOf(ports),
    // An unwritable path that still conflicts parks again before any session (0020).
    park: parkIdleOf(ports, control),
    itemMax: itemMaxOf(ports),
    ...given("warn", ports.warn),
  });
  return () => resumes;
}

/** The review rounds with the real reviewer launcher on the run ports (DIPO-219). */
function buildReviews(
  ports: RunPorts,
  control: RunControl,
  ingest: OfficeIngest,
  startsPaused: StartsPaused | null,
  fixRounds: FixRounds,
): Reviews {
  const sessions = new ReviewLauncher({
    clock: ports.clock,
    ids: ports.ids,
    offices: ports.offices,
    worker: ports.worker,
    git: ports.git,
    runtimeDir: ports.runtimeDir,
    tmpRoot: ports.tmpRoot,
    ...given("tempOwner", ports.tempOwner),
    hosts: ports.hosts,
    ingest: ports.resumeIngest?.(ingest) ?? ingest,
    control: trackerOf(ports, control),
    ...given("boxes", ports.reviewBoxes),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
  return new Reviews({
    stories: ports.stories,
    clock: ports.clock,
    ids: ports.ids,
    offices: ports.offices,
    git: gitReviewOps(ports.git),
    story: baseStoryFacts(ports.base),
    sessions,
    steering: ports.steering,
    encode: (op) => ports.worker.encode(op),
    ender: () => control,
    adapter: ports.worker.id,
    ...given("holds", ports.outcomes?.holds),
    startsPaused: () => startsPaused ?? undefined,
    // Once the reviewer exited after its verdict, the head's fix round may decide (DIPO-148).
    onReviewed: (office, runId, agent) => {
      void fixRounds.consider(office, runId, agent === undefined ? {} : { exited: agent });
    },
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
}

function buildReattacher(
  ports: RunPorts,
  control: RunControl | null,
  ingest: OfficeIngest,
  outcomes: RunOutcomes | null,
): RunReattacher | null {
  if (control === null || ports.reattach === undefined) return null;
  return new RunReattacher({
    ...ports.reattach,
    clock: ports.clock,
    offices: ports.offices,
    ingest,
    control,
    ...given("outcomes", outcomes ?? undefined),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
}

function buildLauncher(
  ports: RunPorts,
  control: RunControl | null,
  ingest: OfficeIngest,
): RunLauncher {
  return new RunLauncher({
    stories: ports.stories,
    worker: ports.worker,
    git: ports.git,
    dependencies: async (office, ids) =>
      ids.length === 0 ? [] : (await ports.base.read(office, ids)).views,
    runtimeDir: ports.runtimeDir,
    tmpRoot: ports.tmpRoot,
    hosts: ports.hosts,
    ingest,
    ...(control === null ? {} : { control: trackerOf(ports, control) }),
    release: ports.release,
    ...given("boxes", ports.boxes),
    // A run's box gets the install of the office's current run profile (DIPO-294).
    profile: profileOf(ports),
    ...given("warn", ports.warn),
  });
}

/** The office's current run profile, whose install a run's box gets (DIPO-294). */
function profileOf(ports: RunPorts): (office: OfficeId) => RunProfile | null {
  return (office) => {
    const handle = ports.offices.get(office);
    return handle === undefined ? null : (currentProfile(handle)?.profile ?? null);
  };
}

/**
 * The exit port of worker outcomes: each exit decision, then the places (a session ended, so its place may be free) and `afterExit` (the
 * run temp directory sweep). A reviewer session's turns and exit go to the review rounds
 * (DIPO-219). Null without worker outcomes.
 */
function exitPortOf(ports: RunPorts, built: Outcomes | null): RunOutcomesPort | null {
  if (built === null) return null;
  const { outcomes, places, reviews } = built;
  const afterExit = ports.afterExit;
  // Only the developer's exits: a reviewer's go to the review rounds (`reviews.route`).
  const developer =
    ports.beforeExit === undefined ? outcomes : beforeRunExits(outcomes, ports.beforeExit);
  return afterRunExits(reviews.route(developer), () => {
    places.drainAll();
    afterExit?.();
  });
}

/** `port` with `before` awaited for the run before each exit is decided (DIPO-376). */
function beforeRunExits(
  port: RunOutcomesPort,
  before: (runId: string) => Promise<void>,
): RunOutcomesPort {
  return {
    onTurnProblem: (view, problem) => port.onTurnProblem(view, problem),
    onPlanLimit: (view, limit) => port.onPlanLimit(view, limit),
    onModelSwitched: (view, model) => port.onModelSwitched(view, model),
    answered: (view) => port.answered(view),
    ...(port.onReview === undefined
      ? {}
      : { onReview: (view, report) => port.onReview?.(view, report) ?? Promise.resolve() }),
    onExit: async (exit) => {
      await before(exit.view.runId);
      await port.onExit(exit);
    },
  };
}

/**
 * The one connect step of the run services (DIPO-318): each partner a service calls but was built
 * before is connected here, once every service exists.
 */
function connectRunPartners(
  partners: RunPartners,
  services: {
    readonly ingest: OfficeIngest;
    readonly built: Outcomes | null;
    readonly exitPort: RunOutcomesPort | null;
  },
): void {
  const { built } = services;
  // Run control <-> ingestion: ingestion's hooks call the control, and the control flushes
  // ingestion's output before it decides.
  partners.ingest.connect(services.ingest);
  // `work.answer` -> the resumption, built on worker outcomes, which need ingestion.
  partners.resumption.connect(built?.resumption ?? null);
  // Run control -> the exit decisions of worker outcomes, which end runs through the control.
  partners.exitPort.connect(services.exitPort);
  // Run control and worker outcomes -> the starts paused, which resume parks through the
  // resumption.
  partners.startsPaused.connect(built?.startsPaused ?? null);
  // Worker outcomes, the starts paused and the fix rounds -> the places, which start resumes,
  // reviews and fix rounds.
  partners.places.connect(built?.places ?? null);
  // Worker outcomes -> the fix rounds, which continue sessions through worker outcomes.
  partners.fixRounds.connect(built?.fixRounds ?? null);
}

/** Builds the run services from `ports`. */
export function composeRuns(ports: RunPorts): ComposedRuns {
  const partners = runPartners();
  const control = buildControl(ports, partners);
  const listeners = buildRunListeners(ports, partners);
  const { answers } = listeners;
  const ingest = buildIngest(ports, control, listeners);
  const built = buildOutcomes(ports, control, ingest, partners);
  const outcomes = built?.outcomes ?? null;
  const exitPort = exitPortOf(ports, built);
  connectRunPartners(partners, { ingest, built, exitPort });
  const reattacher = buildReattacher(ports, control, ingest, outcomes);
  const launcher = buildLauncher(ports, control, ingest);
  const auditSessions = new AuditSessions({
    clock: ports.clock,
    ids: ports.ids,
    offices: ports.offices,
    worker: ports.worker,
    git: ports.git,
    hosts: ports.hosts,
    steering: ports.steering,
    runtimeDir: ports.runtimeDir,
    tmpRoot: ports.tmpRoot,
    ...given("boxes", ports.planningBoxes),
    ...given("tempOwner", ports.tempOwner),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
  const audits = new IdeaAudits({
    clock: ports.clock,
    offices: ports.offices,
    runner: () => auditSessions,
    ...given("active", ports.scheduling),
    ...given("onChanged", ports.onChanged),
    ...given("warn", ports.warn),
  });
  return {
    ingest,
    answers,
    control,
    outcomes,
    resumption: built?.resumption ?? null,
    resumer: built?.resumer ?? null,
    startsPaused: built?.startsPaused ?? null,
    places: built?.places ?? null,
    reviews: built?.reviews ?? null,
    fixRounds: built?.fixRounds ?? null,
    inReviewConflict: built?.inReviewConflict ?? null,
    launcher,
    reattacher,
    planning: new PlanningSessions({
      clock: ports.clock,
      ids: ports.ids,
      offices: ports.offices,
      worker: ports.worker,
      git: ports.git,
      hosts: ports.hosts,
      steering: ports.steering,
      runtimeDir: ports.runtimeDir,
      tmpRoot: ports.tmpRoot,
      ...given("boxes", ports.planningBoxes),
      ...given("desk", ports.planningDesk),
      ...given("lane", ports.planningLane),
      ...given("gate", ports.planningGate),
      // An aside the session sends is audited when it arrives (DIPO-452).
      onIdea: (office) => audits.poke(office),
      ...given("tempOwner", ports.tempOwner),
      ...given("onChanged", ports.onChanged),
      ...given("warn", ports.warn),
    }),
    audits,
    auditSessions,
    sessions: new SessionRuns({
      clock: ports.clock,
      ids: ports.ids,
      offices: ports.offices,
      worker: ports.worker,
      git: ports.git,
      hosts: ports.hosts,
      steering: ports.steering,
      runtimeDir: ports.runtimeDir,
      tmpRoot: ports.tmpRoot,
      ...given("tempOwner", ports.tempOwner),
      ...given("onChanged", ports.onChanged),
      ...given("warn", ports.warn),
    }),
  };
}
