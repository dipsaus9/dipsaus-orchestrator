<background>
{{background}}
</background>
