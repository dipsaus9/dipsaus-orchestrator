// The single write path for a story's fields (0010), the same in both lanes: view, parse,
// change the typed value, emit canonically, splice so every byte outside the block is unchanged,
// write with `task edit --description` (or `draft edit`), read back and compare. Just before writing
// the description is read again; if it changed since the first read, it is parsed again and the
// target-state change reapplied. Labels change only with `--add-label` and `--remove-label`.
//
// Two values are the same when their canonical emits are the same, so an absent key and a key set
// to `undefined` compare equal.
//
// The splice works on the description as the CLI printed it; NFC normalisation is only for parsing
// and comparing, so text outside the block (NFD included) is written back byte for byte.
//
// Every `writeFields` and `editLabels` call must go through the per-worktree serial git queue
// (DIPO-31). The caller (DIPO-34) owns that; this module does not queue.

import { FieldBlock } from "@dipsaus-orchestrator/contract";

import { emitFieldBlock, parseFieldBlock, spliceFieldBlock } from "../../story-store/fields/block";
import { isValidLabel, readLabels, type StoryLabels } from "../../story-store/fields/labels";
import type { PlainTask } from "../../story-store/story";
import { parseView } from "../plain";
import { runBacklog, type BacklogCli } from "../runner";

/** A story the engine writes: a task or a draft, by id, in the worktree `cwd`. */
export interface StoryTarget {
  readonly cli: BacklogCli;
  readonly cwd: string;
  readonly id: string;
  /** `task` by default. */
  readonly kind?: "task" | "draft";
}

export interface LabelChange {
  readonly add?: readonly string[];
  readonly remove?: readonly string[];
}

/**
 * The `task edit` options for a label change: one `--add-label` or `--remove-label` per label.
 * Throws when a label is outside the grammar, so it never reaches the CLI.
 */
export function labelEditArgs(change: LabelChange): string[] {
  const args: string[] = [];
  for (const [option, labels] of [
    ["--add-label", change.add ?? []],
    ["--remove-label", change.remove ?? []],
  ] as const) {
    for (const label of labels) {
      if (!isValidLabel(label)) {
        throw new Error(`label "${label}" is outside the grammar [a-z0-9-]+(:[A-Za-z0-9-]+)?`);
      }
      args.push(option, label);
    }
  }
  return args;
}

/** How many times a write re-reads a description that changed under it before giving up. */
export const MAX_WRITE_ATTEMPTS = 3;

/** A write the CLI did not apply as asked, or that kept racing another writer. */
export class FieldWriteError extends Error {
  constructor(
    readonly id: string,
    reason: string,
  ) {
    super(`writing the fields of ${id} failed: ${reason}`);
    this.name = "FieldWriteError";
  }
}

/** `<kind> view <id> --plain`, parsed; NFC-normalised unless `normalize` is false. */
export async function viewStory(target: StoryTarget, normalize = true): Promise<PlainTask> {
  const { stdout } = await runBacklog(target.cli, target.cwd, [
    target.kind ?? "task",
    "view",
    target.id,
    "--plain",
  ]);
  return parseView(stdout, { normalize });
}

/** The CLI stores the description trimmed and with LF line endings; comparing also NFC-normalises. */
function comparable(description: string): string {
  return description.replace(/\r\n/g, "\n").normalize("NFC").trim();
}

/**
 * Applies the target-state `change` to the story's field block and writes it through the single
 * write path. Returns the value now stored. Throws `FieldBlockError` (R02) when the description's
 * block does not parse, and `FieldWriteError` when the read back differs or the description kept
 * changing between reads.
 */
export async function writeFields(
  target: StoryTarget,
  change: (fields: FieldBlock) => FieldBlock,
): Promise<FieldBlock> {
  let read = (await viewStory(target, false)).description;
  for (let attempt = 0; attempt < MAX_WRITE_ATTEMPTS; attempt++) {
    const { fields } = parseFieldBlock(read);
    const next = FieldBlock.parse(change(fields));
    if (emitFieldBlock(next) === emitFieldBlock(fields)) return fields;
    const description = spliceFieldBlock(read, next);

    const latest = (await viewStory(target, false)).description;
    if (latest !== read) {
      read = latest;
      continue;
    }

    await runBacklog(target.cli, target.cwd, [
      target.kind ?? "task",
      "edit",
      target.id,
      "--description",
      description,
    ]);

    const back = (await viewStory(target, false)).description;
    if (comparable(back) !== comparable(description)) {
      throw new FieldWriteError(
        target.id,
        "the description read back differs from the one written",
      );
    }
    const stored = parseFieldBlock(back).fields;
    if (emitFieldBlock(stored) !== emitFieldBlock(next)) {
      throw new FieldWriteError(
        target.id,
        "the field block read back differs from the one written",
      );
    }
    return stored;
  }
  throw new FieldWriteError(
    target.id,
    `the description changed between reads ${MAX_WRITE_ATTEMPTS} times`,
  );
}

/**
 * Adds and removes labels with `--add-label` and `--remove-label` only, reads back and checks that
 * every added label is present and every removed one gone. Returns the labels now stored.
 */
export async function editLabels(target: StoryTarget, change: LabelChange): Promise<StoryLabels> {
  const args = labelEditArgs(change);
  if (args.length > 0) {
    await runBacklog(target.cli, target.cwd, [target.kind ?? "task", "edit", target.id, ...args]);
  }
  const labels = (await viewStory(target)).labels;
  const missing = (change.add ?? []).filter((label) => !labels.includes(label));
  const left = (change.remove ?? []).filter((label) => labels.includes(label));
  if (missing.length > 0 || left.length > 0) {
    throw new FieldWriteError(
      target.id,
      `labels read back differ: missing ${JSON.stringify(missing)}, still present ${JSON.stringify(left)}`,
    );
  }
  return readLabels(labels);
}
