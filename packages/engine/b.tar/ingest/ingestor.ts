// Worker event ingestion (0007; 0005). For each
// tracked run and agent the engine reads the complete lines of the host's `events.ndjson` from the
// stored `processed_offset`, runs the adapter's pure `interpret` over them, and in one
// transaction writes the derived facts (agent details, usage rows, output chunks), any change-log
// entries that are due, the parser state and the new offset. A turn report's met criteria are
// stored on the run there too, with a `work.progress` when the count changed (DIPO-85). A crash
// before the commit leaves offset and facts as they were, so the next pass neither skips nor
// repeats an event.
//
// Debounce before the log (0005): stored output becomes a `work.output` entry per run
// every 250 ms or at 16 KiB, and `usage.updated` at most once per second, on the injected clock.
// A pass starts when the host announces `advanced` on its socket, with a `stat` poll every second
// as fallback; `fs.watch` is not used. A host event file that shrank below the offset or was
// replaced stops ingestion for that run and reports `ingest.fileChanged`; run control parks
// the run.
//
// Stream drift (DIPO-315). The adapter turns each line it cannot read into a `streamDrift` event.
// The ingestor counts the `schema` and `dropped` ones per agent in `ingest_cursors.drift_lines`,
// in the pass that read them, so a restart neither loses nor repeats one; a run's count is the sum
// over its agents. A drift event at which the run's count is at `STREAM_DRIFT_LINES` or above, and
// every `usage` drift (a result whose usage cannot be read, a completed turn that reports none),
// goes to `onStreamDrift` inside the pass, and the run parks `worker-failed` ("stream drift")
// (`run/control.ts`). A `newerVersion` event posts one `engine.notice` per office and version,
// recorded in `once_notices` in the same transaction.

import { createHash } from "node:crypto";

import type { Clock, Cursor, RunId, TimerHandle, WorkRef } from "@dipsaus-orchestrator/contract";

import { appendEntries, type NewEntry } from "../changelog/log";
import type { OfficeHandle } from "../db/office";
import { STREAM_DRIFT_LINES } from "../records/caps";
import { recordReportedCriteria } from "../records/criteria";
import { clearSignals, LIVENESS_SIGNALS } from "../records/signals";
import { endAgent, recordAgent, recordAgentStart, recordInitRejected } from "../records/agents";
import { recordExitLine, setProcessedOffset } from "../records/worker-hosts";
import { runProgress, withWorkViews } from "../views/work";
import type { ExitRecord, HostLine, ParseState, WorkerEvent } from "../workers/types";
import { readCompleteLines, readRange, statEventFile, type FileIdentity } from "./event-file";
import { byteLength, DEFAULT_OUTPUT_PRIVACY, type OutputPrivacy, outputText } from "./output";
import { HOST_EVENTS_SOURCE, pendingWorkerOutput, type StorylessEvents } from "./pending";
import {
  applyProxiedTurn,
  applyTurnTotals,
  feedFinalChanges,
  recordCompaction,
  finalRows,
  readUsage,
  recordProxiedCost,
  recordReportedCost,
  recordUsageMessage,
  setElapsed,
  setLiveUsage,
  type UsageScope,
} from "../records/usage";

/** The engine notice code a changed host event file reports. */
export const FILE_CHANGED_CODE = "ingest.fileChanged";
/** The engine notice code of a worker newer than the adapter was checked with (DIPO-315). */
export const NEWER_VERSION_CODE = "worker.newerVersion";

/** What the ingestor counted at a stream drift that decides (DIPO-315). */
export interface StreamDriftCount {
  /** The run's unreadable lines (`schema` and `dropped`) so far, over all its agents. */
  readonly lines: number;
  /** The count at which the run parks. */
  readonly threshold: number;
}

/** Debounce and poll defaults (0005, 0007). */
export interface IngestTimings {
  readonly outputFlushMs: number;
  readonly outputFlushBytes: number;
  readonly usageIntervalMs: number;
  readonly pollMs: number;
}

export const INGEST_DEFAULTS: IngestTimings = {
  outputFlushMs: 250,
  outputFlushBytes: 16 * 1024,
  usageIntervalMs: 1000,
  pollMs: 1000,
};

/** The interpret half of a worker adapter (0008). */
export interface IngestAdapter {
  interpret(
    line: HostLine,
    state: ParseState,
  ): { readonly events: readonly WorkerEvent[]; readonly state: ParseState };
}

/** One run and agent to ingest; its `worker_hosts` row names the event file and offset. */
export interface IngestTarget extends UsageScope {
  /** The model the run planned; replaced by the model the worker reports at start. */
  readonly model: string;
  /**
   * Who works on what, for `work.output` and `usage.updated`. A run with no story (a `session`
   * run, 0007) has none: its facts are stored, but no work event.
   */
  readonly work?: WorkRef;
  /**
   * The output and usage events of a run with no story that a client follows (a planning
   * session, DIPO-447), in place of `work.output` and `usage.updated`.
   */
  readonly storyless?: StorylessEvents;
  readonly adapter: IngestAdapter;
  /** The parser state the first pass starts from; later passes use the stored one. */
  readonly initialState: ParseState;
}

export interface FileChangedReport {
  readonly run: string;
  readonly agent: string;
  readonly path: string;
  readonly detail: string;
}

export interface IngestHooks {
  /** The host event file changed; ingestion for the run stopped (DIPO-57 parks it). */
  readonly onFileChanged?: (report: FileChangedReport) => void;
  /** The worker failed its start checks; the caller stops it at once. */
  readonly onInitRejected?: (run: string, agent: string, reason: string) => void;
  /**
   * Called inside the pass transaction right after a `usage` or `turn` event was folded into the
   * stored totals, so a reader sees the totals as of that event (DIPO-50 caps). It must not throw
   * and must not write; what it learns is acted on after the commit.
   */
  readonly onEventApplied?: (run: string, agent: string, event: WorkerEvent) => void;
  /**
   * Called inside the pass transaction at a `streamDrift` event that decides (DIPO-315): the run's
   * count reached the threshold, or the turn's usage cannot be read. Like `onEventApplied`, it
   * must not throw and must not write; the run is parked after the commit, in event order.
   */
  readonly onStreamDrift?: (
    run: string,
    agent: string,
    event: Extract<WorkerEvent, { t: "streamDrift" }>,
    count: StreamDriftCount,
  ) => void;
  /** Every worker event of a committed pass, in order, for health and caps. */
  readonly onWorkerEvents?: (run: string, agent: string, events: readonly WorkerEvent[]) => void;
  /**
   * The worker's exit line was ingested; its usage is final. `end` carries the exit record and the
   * parser state after the exit line, so the engine can ask the adapter's `result` (DIPO-51).
   */
  readonly onEnded?: (run: string, agent: string, end: IngestedExit) => void;
  /**
   * A pass committed complete lines of the run (DIPO-52): the worker is alive, so the watchdog
   * starts its quiet and stall timers again. `quiet` and `no-output` were cleared in the pass.
   */
  readonly onLines?: (run: string, agent: string) => void;
  /**
   * Change-log entries were appended (DIPO-52), so the daemon sends them to subscribers. Called
   * after the transaction that appended them, once per transaction.
   */
  readonly onAppended?: () => void;
}

/** A worker exit as ingestion read it (DIPO-51). */
export interface IngestedExit {
  readonly exit: ExitRecord;
  /** The parser state after the exit line. */
  readonly state: ParseState;
}

/** The exit record of an `exit` host line; unknown fields read as null. */
export function exitRecordOf(data: string): ExitRecord {
  try {
    const value = JSON.parse(data) as Record<string, unknown> | null;
    const signal = typeof value?.["signal"] === "string" ? value["signal"] : null;
    return {
      code: typeof value?.["code"] === "number" ? value["code"] : null,
      signal,
      // The host inferred the signal from the one it sent last (DIPO-88).
      ...(signal !== null && value?.["signalInferred"] === true ? { signalInferred: true } : {}),
    };
  } catch {
    return { code: null, signal: null };
  }
}

export interface IngestorOptions {
  readonly office: OfficeHandle;
  readonly clock: Clock;
  readonly hooks?: IngestHooks;
  readonly timings?: Partial<IngestTimings>;
  /** Called for a host line that is not a `{ t, ch, data }` object; the line is skipped. */
  readonly warn?: (message: string, fields: Readonly<Record<string, unknown>>) => void;
  /**
   * The office's privacy opt-ins in force (0007, DIPO-83), read at every pass so a
   * reloaded configuration applies to the next output. Without it nothing beyond the default is
   * stored.
   */
  readonly privacy?: () => OutputPrivacy;
  /**
   * Rewrites a pass's output text of `run` before it is stored in `output_chunks`, in the pass
   * transaction: the web check redacts env values from web lines (0020, DIPO-164).
   * Without it the text is stored as it is.
   */
  readonly redactOutput?: (run: string, text: string) => string;
}

export type PassStatus = "ingested" | "idle" | "stopped" | "ended" | "fileChanged";

export interface PassResult {
  readonly status: PassStatus;
  readonly lines: number;
  readonly offset: number;
}

/** Something that can announce `advanced` offsets: the host client (DIPO-44). */
export interface AdvancedSource {
  watch(listener: (offset: number) => void): Promise<number | null>;
}

interface CursorRow {
  path: string;
  drift_lines: number;
  device: number | null;
  inode: number | null;
  read_offset: number;
  last_line_hash: string | null;
  last_line_bytes: number | null;
  parse_state: string;
  first_line_t: number | null;
  last_line_t: number | null;
  output_emitted_to: number;
  ended_at: number | null;
  changed_at: number | null;
}

interface Tracked {
  readonly target: IngestTarget;
  poll: TimerHandle | null;
  outputTimer: TimerHandle | null;
  usageTimer: TimerHandle | null;
  lastUsageAt: number | null;
  usageDirty: boolean;
  done: boolean;
}

const SOURCE = HOST_EVENTS_SOURCE;
const decoder = new TextDecoder();

function keyOf(run: string, agent: string): string {
  return `${run}\u0000${agent}`;
}

function parseHostLine(text: string): HostLine | null {
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    return null;
  }
  if (typeof value !== "object" || value === null) return null;
  const { t, ch, data } = value as Record<string, unknown>;
  if (typeof t !== "number" || typeof ch !== "string" || typeof data !== "string") return null;
  return { t, ch, data };
}

/** Runs whose host event file changed and that have not ended, for DIPO-57. */
export function fileChangedRuns(office: OfficeHandle): FileChangedReport[] {
  return office
    .all<{ run_id: string; agent_id: string; path: string; changed_detail: string }>(
      `select run_id, agent_id, path, changed_detail from ingest_cursors
       where office_id = $office_id and changed_at is not null and ended_at is null
       order by changed_at, run_id`,
    )
    .map((row) => ({
      run: row.run_id,
      agent: row.agent_id,
      path: row.path,
      detail: row.changed_detail,
    }));
}

export class Ingestor {
  readonly #office: OfficeHandle;
  readonly #clock: Clock;
  readonly #hooks: IngestHooks;
  readonly #timings: IngestTimings;
  readonly #warn: NonNullable<IngestorOptions["warn"]>;
  readonly #privacy: () => OutputPrivacy;
  readonly #redactOutput: (run: string, text: string) => string;
  readonly #tracked = new Map<string, Tracked>();

  constructor(options: IngestorOptions) {
    this.#office = options.office;
    this.#clock = options.clock;
    this.#hooks = options.hooks ?? {};
    this.#timings = { ...INGEST_DEFAULTS, ...options.timings };
    this.#warn = options.warn ?? (() => {});
    this.#privacy = options.privacy ?? (() => DEFAULT_OUTPUT_PRIVACY);
    this.#redactOutput = options.redactOutput ?? ((_run, text) => text);
  }

  /**
   * Starts ingesting a run's agent: records the agent and its cursor if they are new, runs a
   * first pass and starts the 1 s `stat` poll. The `worker_hosts` row must exist.
   */
  track(target: IngestTarget): PassResult {
    const key = keyOf(target.run, target.agent);
    if (this.#tracked.has(key)) return this.pass(target.run, target.agent);
    const now = this.#clock.now();
    this.#office.immediate(() => {
      const host = this.#office.get<{ event_file: string; processed_offset: number }>(
        `select event_file, processed_offset from worker_hosts
         where office_id = $office_id and run_id = $run and agent_id = $agent`,
        { run: target.run, agent: target.agent },
      );
      if (host === null) {
        throw new Error(`No worker host is recorded for ${target.run} agent ${target.agent}.`);
      }
      recordAgent(this.#office, {
        agentId: target.agent,
        runId: target.run,
        role: target.role,
        model: target.model,
        startedAt: now,
      });
      // A new agent's output continues the run's stored output, after what earlier agents wrote.
      const end = this.#outputEnd(target.run);
      this.#office.run(
        `insert or ignore into ingest_cursors (office_id, run_id, agent_id, source_kind, path,
           read_offset, parse_state, output_emitted_to, updated_at)
         values ($office_id, $run, $agent, $kind, $path, $offset, $state, $end, $now)`,
        {
          run: target.run,
          agent: target.agent,
          kind: SOURCE,
          path: host.event_file,
          offset: host.processed_offset,
          state: JSON.stringify(target.initialState),
          end,
          now,
        },
      );
    });
    this.#tracked.set(key, {
      target,
      poll: null,
      outputTimer: null,
      usageTimer: null,
      lastUsageAt: null,
      usageDirty: false,
      done: false,
    });
    const result = this.pass(target.run, target.agent);
    const tracked = this.#tracked.get(key);
    if (tracked !== undefined && !tracked.done) {
      // Output stored before a restart but not yet sent as an event goes out on the timer.
      this.#armOutput(tracked);
      this.#armPoll(tracked);
    }
    return result;
  }

  /** The host announced `advanced` (DIPO-44): run a pass now. */
  announce(run: string, agent: string): PassResult {
    return this.pass(run, agent);
  }

  /** Subscribes to a host's `advanced` announcements and catches up once. */
  async watch(run: string, agent: string, source: AdvancedSource): Promise<void> {
    await source.watch(() => {
      this.announce(run, agent);
    });
    this.announce(run, agent);
  }

  /**
   * Stops timers for one agent; stored facts and the cursor stay. Its stored output not yet sent
   * goes out as `work.output` first, since no timer of this agent sends it later (DIPO-57).
   */
  untrack(run: string, agent: string): void {
    const tracked = this.#tracked.get(keyOf(run, agent));
    if (tracked === undefined) return;
    this.#stopTimers(tracked);
    const at = this.#clock.now();
    this.#office.immediate(() => this.#append(this.#outputEntries(tracked.target), at));
    this.#tracked.delete(keyOf(run, agent));
  }

  /** Stops every timer; nothing pending is lost, because it is all stored. */
  close(): void {
    for (const tracked of this.#tracked.values()) this.#stopTimers(tracked);
    this.#tracked.clear();
  }

  /**
   * Writes pending `work.output` of the run now. Call it before a state change of the run
   * (0005: state changes flush pending output first). Returns the last cursor written.
   */
  flushOutput(run: string): Cursor | undefined {
    let cursor: Cursor | undefined;
    for (const tracked of this.#tracked.values()) {
      if (tracked.target.run !== run) continue;
      this.#clearOutputTimer(tracked);
      const at = this.#clock.now();
      cursor =
        this.#office.immediate(() => this.#append(this.#outputEntries(tracked.target), at)) ??
        cursor;
    }
    return cursor;
  }

  /** One pass for a tracked agent: read, interpret and commit the complete lines past the offset. */
  pass(run: string, agent: string): PassResult {
    const tracked = this.#tracked.get(keyOf(run, agent));
    if (tracked === undefined) throw new Error(`${run} agent ${agent} is not tracked.`);
    const { target } = tracked;
    const cursor = this.#cursor(target);
    const offset = this.#processedOffset(target);
    if (cursor.changed_at !== null) return this.#finish(tracked, "stopped", 0, offset);
    if (cursor.ended_at !== null) return this.#finish(tracked, "ended", 0, offset);

    const identity = statEventFile(cursor.path);
    const changed = this.#changeOf(cursor, identity, offset);
    if (changed !== null) {
      this.#fileChanged(tracked, cursor.path, changed);
      return this.#finish(tracked, "fileChanged", 0, offset);
    }
    if (identity === null) return { status: "idle", lines: 0, offset };
    const lines = readCompleteLines(cursor.path, offset, identity.size);
    if (lines.length === 0) {
      // Record the identity as soon as the file exists, so a replacement is caught even before the
      // first complete line.
      if (cursor.device === null) this.#recordIdentity(target, identity);
      return { status: "idle", lines: 0, offset };
    }

    const now = this.#clock.now();
    const privacy = this.#privacy();
    const events: WorkerEvent[] = [];
    const rejected: string[] = [];
    let exited = false;
    let exit: ExitRecord = { code: null, signal: null };
    let endState: ParseState = {};
    let usageDirty = false;
    let usageSent = false;
    // Unreadable lines this pass added to the agent's count (DIPO-315).
    let driftAdded = 0;
    const end = lines[lines.length - 1]?.end ?? offset;

    this.#office.immediate(() => {
      // Rows a run's end already made final (0007): what changes in them now
      // feeds `usage_daily` as a change only.
      const finalBefore = finalRows(this.#office, run, agent);
      let state = JSON.parse(cursor.parse_state) as ParseState;
      let firstT = cursor.first_line_t;
      let lastT = cursor.last_line_t;
      let model = this.#agentModel(target);
      let usageChanged = false;
      // The criteria count shown before the pass's first report; undefined when none came.
      let criteriaBefore: number | null | undefined;
      // The run's unreadable lines before this pass, over all its agents (DIPO-315).
      const driftBefore = this.#runDriftLines(run);
      const versionNotices: NewEntry[] = [];
      let text = "";
      for (const line of lines) {
        const hostLine = parseHostLine(line.text);
        if (hostLine === null) {
          this.#warn("skipped an event line that is not a host line", {
            run,
            agent,
            end: line.end,
          });
          continue;
        }
        firstT ??= hostLine.t;
        lastT = hostLine.t;
        if (hostLine.ch === "exit") {
          exited = true;
          exit = exitRecordOf(hostLine.data);
        }
        const step = target.adapter.interpret(hostLine, state);
        state = step.state;
        for (const event of step.events) {
          events.push(event);
          text += outputText(event, privacy);
          switch (event.t) {
            case "usage":
              // A box session's tokens are the model proxy's count (DIPO-425): none added here,
              // but the caps are checked as of this event.
              if (event.proxied !== true) {
                usageChanged = recordUsageMessage(this.#office, target, event, now) || usageChanged;
              }
              this.#hooks.onEventApplied?.(run, agent, event);
              break;
            case "liveUsage":
              // The turn in progress, for the live view only (DIPO-296); the caps never read it.
              setLiveUsage(this.#office, target, model, event, now);
              usageChanged = true;
              break;
            case "turn":
              if (event.proxied === true) {
                // The model proxy counted the turn's tokens (DIPO-425): the turn adds its turns
                // and keeps the CLI's cost, so it is counted once.
                applyProxiedTurn(this.#office, target, { model, count: event.numTurns }, now);
                recordProxiedCost(this.#office, target, event.costUsd ?? {}, now);
              } else {
                applyTurnTotals(
                  this.#office,
                  target,
                  event.totals,
                  { model, count: event.numTurns },
                  now,
                );
                for (const missing of recordReportedCost(
                  this.#office,
                  run,
                  agent,
                  event.costUsd ?? {},
                )) {
                  this.#warn("the CLI reported a cost for a model without a usage row", {
                    run,
                    agent,
                    model: missing,
                  });
                }
              }
              usageChanged = true;
              // The criteria the report marks met are the run's progress now (DIPO-85).
              if (event.report !== null && target.work !== undefined) {
                criteriaBefore ??= runProgress(this.#office, run as RunId)?.criteriaMet ?? null;
                recordReportedCriteria(this.#office, run, event.report);
              }
              this.#hooks.onEventApplied?.(run, agent, event);
              break;
            case "started":
              model = event.model;
              recordAgentStart(this.#office, agent, {
                model: event.model,
                sessionId: event.sessionId,
                version: event.version,
              });
              break;
            case "compacted":
              // The adapter emits one event per compaction; no preTokens when it had no count.
              recordCompaction(this.#office, target, event.preTokens ?? null, now);
              break;
            case "streamDrift": {
              if (event.kind !== "usage") driftAdded += 1;
              const count = { lines: driftBefore + driftAdded, threshold: STREAM_DRIFT_LINES };
              if (event.kind === "usage" || count.lines >= count.threshold) {
                this.#hooks.onStreamDrift?.(run, agent, event, count);
              }
              break;
            }
            case "newerVersion":
              versionNotices.push(...this.#newerVersion(target, event, now));
              break;
            case "initRejected":
              rejected.push(event.reason);
              recordInitRejected(this.#office, agent, event.reason);
              break;
            default:
              break;
          }
        }
      }

      if (text !== "") text = this.#redactOutput(run, text);
      if (text !== "") {
        const from = this.#outputEnd(run);
        this.#office.run(
          `insert into output_chunks (office_id, run_id, source, from_offset, to_offset, agent_id,
             text, at)
           values ($office_id, $run, 'worker', $from, $to, $agent, $text, $now)`,
          { run, from, to: from + byteLength(text), agent, text, now },
        );
      }
      if (firstT !== null && lastT !== null && (usageChanged || this.#hasTotals(target))) {
        setElapsed(this.#office, target, model, lastT - firstT, now);
      }

      const last = lines[lines.length - 1]?.text ?? "";
      const lastStart = lines.length > 1 ? (lines[lines.length - 2]?.end ?? offset) : offset;
      this.#office.run(
        `update ingest_cursors set read_offset = $end, device = $device, inode = $inode,
           size = $size, last_line_hash = $hash, last_line_bytes = $bytes, parse_state = $state, first_line_t = $first,
           last_line_t = $last, updated_at = $now, ended_at = $ended,
           drift_lines = drift_lines + $drift
         where office_id = $office_id and run_id = $run and agent_id = $agent
           and source_kind = $kind`,
        {
          drift: driftAdded,
          end,
          device: identity.device,
          inode: identity.inode,
          size: identity.size,
          hash: createHash("sha256").update(last).digest("hex"),
          bytes: end - lastStart,
          state: JSON.stringify(state),
          first: firstT,
          last: lastT,
          now,
          ended: exited ? now : null,
          run,
          agent,
          kind: SOURCE,
        },
      );
      setProcessedOffset(this.#office, run, agent, end);

      // Change-log entries that are due now, output first so order stays causal.
      const entries: NewEntry[] = [];
      const pending = this.#outputEnd(run) - this.#emittedTo(target);
      // A session the maintainer talks to (DIPO-447) gets each answer whole at its turn end, ahead
      // of the update that says it waits for the next message.
      const answered = target.storyless !== undefined && events.some((event) => event.t === "turn");
      if (exited || answered || rejected.length > 0 || pending >= this.#timings.outputFlushBytes) {
        entries.push(...this.#outputEntries(target));
      }
      entries.push(...versionNotices);
      // A `work.progress` only when the count the view shows changed (DIPO-85).
      const progress =
        criteriaBefore === undefined ? null : runProgress(this.#office, target.run as RunId);
      if (
        progress !== null &&
        progress.criteriaMet !== criteriaBefore &&
        target.work !== undefined
      ) {
        entries.push({
          type: "work.progress",
          key: target.work.key,
          run: target.work.run,
          delta: { work: target.work, progress },
        });
      }
      usageDirty = tracked.usageDirty || usageChanged;
      const dueAt = (tracked.lastUsageAt ?? -Infinity) + this.#timings.usageIntervalMs;
      if (usageDirty && (exited || now >= dueAt)) {
        entries.push(...this.#usageEntries(target));
        usageSent = true;
      }
      // A line clears `no-output` (0009, DIPO-52).
      for (const cleared of clearSignals(this.#office, run, LIVENESS_SIGNALS, now)) {
        if (target.work === undefined) continue;
        entries.push({
          type: "work.observed",
          key: target.work.key,
          run: target.work.run,
          delta: {
            work: target.work,
            signal: cleared.signal,
            since: new Date(cleared.since).toISOString(),
            clearedAt: new Date(now).toISOString(),
          },
        });
      }
      feedFinalChanges(this.#office, run, agent, finalBefore, now);
      if (exited) {
        endState = state;
        // The cursor ended with the update above, and the host row ends here too (DIPO-330), so
        // retention and keep-awake see an exited host without a daemon restart.
        endAgent(this.#office, {
          runId: run,
          agentId: agent,
          at: now,
          reason: "exited",
          finalizeUsage: true,
          endHost: true,
        });
        // The exit as the host wrote it, for a decision after a restart (DIPO-51). The exit line
        // is the host's last line, so its end is the host's final offset.
        recordExitLine(this.#office, run, agent, exit, end);
      }
      this.#append(entries, now);
    });

    // Only a committed `usage.updated` counts as sent; a rolled-back one is sent again.
    tracked.usageDirty = usageDirty;
    if (usageSent) this.#usageSent(tracked, now);

    if (exited) {
      tracked.done = true;
      this.#stopTimers(tracked);
    } else {
      this.#armOutput(tracked);
      this.#armUsage(tracked);
    }
    this.#hooks.onLines?.(run, agent);
    if (events.length > 0) this.#hooks.onWorkerEvents?.(run, agent, events);
    for (const reason of rejected) this.#hooks.onInitRejected?.(run, agent, reason);
    // Logged only once the pass committed, so a rolled-back pass warns again when it is redone.
    if (driftAdded > 0) {
      this.#warn("worker stream lines could not be read", {
        run,
        agent,
        lines: driftAdded,
        agentTotal: cursor.drift_lines + driftAdded,
      });
    }
    if (exited) this.#hooks.onEnded?.(run, agent, { exit, state: endState });
    return { status: exited ? "ended" : "ingested", lines: lines.length, offset: end };
  }

  // ---- timers --------------------------------------------------------------------------------

  #armPoll(tracked: Tracked): void {
    if (tracked.done || tracked.poll !== null) return;
    tracked.poll = this.#clock.setTimeout(() => {
      tracked.poll = null;
      if (tracked.done) return;
      this.pass(tracked.target.run, tracked.target.agent);
      this.#armPoll(tracked);
    }, this.#timings.pollMs);
  }

  #armOutput(tracked: Tracked): void {
    if (tracked.done || tracked.outputTimer !== null) return;
    if (this.#outputEnd(tracked.target.run) <= this.#emittedTo(tracked.target)) return;
    tracked.outputTimer = this.#clock.setTimeout(() => {
      tracked.outputTimer = null;
      const at = this.#clock.now();
      this.#office.immediate(() => this.#append(this.#outputEntries(tracked.target), at));
    }, this.#timings.outputFlushMs);
  }

  #clearOutputTimer(tracked: Tracked): void {
    if (tracked.outputTimer !== null) this.#clock.clearTimeout(tracked.outputTimer);
    tracked.outputTimer = null;
  }

  #armUsage(tracked: Tracked): void {
    if (tracked.done || !tracked.usageDirty || tracked.usageTimer !== null) return;
    const dueAt = (tracked.lastUsageAt ?? this.#clock.now()) + this.#timings.usageIntervalMs;
    tracked.usageTimer = this.#clock.setTimeout(
      () => {
        tracked.usageTimer = null;
        if (!tracked.usageDirty) return;
        const at = this.#clock.now();
        this.#office.immediate(() => this.#append(this.#usageEntries(tracked.target), at));
        this.#usageSent(tracked, at);
      },
      Math.max(0, dueAt - this.#clock.now()),
    );
  }

  #stopTimers(tracked: Tracked): void {
    for (const handle of [tracked.poll, tracked.outputTimer, tracked.usageTimer]) {
      if (handle !== null) this.#clock.clearTimeout(handle);
    }
    tracked.poll = null;
    tracked.outputTimer = null;
    tracked.usageTimer = null;
  }

  #finish(tracked: Tracked, status: PassStatus, lines: number, offset: number): PassResult {
    tracked.done = true;
    this.#stopTimers(tracked);
    return { status, lines, offset };
  }

  // ---- entries (inside a transaction) --------------------------------------------------------

  /**
   * Appends `entries`, each work entry with the run's `WorkView` derived now (DIPO-52), and has
   * `onAppended` called once the transaction is done. Runs inside the caller's transaction.
   */
  #append(entries: readonly NewEntry[], at: number): Cursor | undefined {
    const cursor = appendEntries(this.#office, withWorkViews(this.#office, entries), { at });
    const notify = this.#hooks.onAppended;
    if (cursor !== undefined && notify !== undefined) queueMicrotask(notify);
    return cursor;
  }

  /** `work.output` for the agent's output not yet sent; advances the emitted mark. */
  #outputEntries(target: IngestTarget): NewEntry[] {
    return pendingWorkerOutput(
      this.#office,
      target.run,
      target.agent,
      target.work,
      target.storyless,
    );
  }

  /** `usage.updated` with the agent's and run's usage now; the caller marks it sent on commit. */
  #usageEntries(target: IngestTarget): NewEntry[] {
    if (target.work === undefined) {
      return target.storyless === undefined ? [] : [target.storyless.usage()];
    }
    return [
      {
        type: "usage.updated",
        key: target.work.key,
        run: target.work.run,
        delta: { work: target.work, usage: readUsage(this.#office, target) },
      },
    ];
  }

  /** After a committed `usage.updated`: nothing pending, and the next one waits its interval. */
  #usageSent(tracked: Tracked, at: number): void {
    tracked.usageDirty = false;
    tracked.lastUsageAt = at;
  }

  // ---- file change ---------------------------------------------------------------------------

  #changeOf(cursor: CursorRow, identity: FileIdentity | null, offset: number): string | null {
    if (identity === null) return offset > 0 ? "event file missing" : null;
    if (
      cursor.device !== null &&
      (cursor.device !== identity.device || cursor.inode !== identity.inode)
    ) {
      return "event file replaced";
    }
    if (identity.size < offset) {
      return `event file is ${identity.size} bytes, below the processed offset ${offset}`;
    }
    // The last processed line must still be where it was: same bytes, ending in a newline.
    const length = cursor.last_line_bytes;
    if (cursor.last_line_hash !== null && length !== null && length > 0 && length <= offset) {
      const bytes = readRange(cursor.path, offset - length, length);
      const intact =
        bytes.byteLength === length &&
        bytes[length - 1] === 0x0a &&
        createHash("sha256")
          .update(decoder.decode(bytes.subarray(0, length - 1)))
          .digest("hex") === cursor.last_line_hash;
      if (!intact) return "event file rewritten before the processed offset";
    }
    return null;
  }

  #fileChanged(tracked: Tracked, path: string, detail: string): void {
    const { target } = tracked;
    const now = this.#clock.now();
    this.#office.immediate(() => {
      const entries: NewEntry[] = [...this.#outputEntries(target)];
      if (tracked.usageDirty) entries.push(...this.#usageEntries(target));
      this.#office.run(
        `update ingest_cursors set changed_at = $now, changed_detail = $detail, updated_at = $now
         where office_id = $office_id and run_id = $run and agent_id = $agent
           and source_kind = $kind`,
        { now, detail, run: target.run, agent: target.agent, kind: SOURCE },
      );
      entries.push({
        type: "engine.notice",
        ...(target.work === undefined ? {} : { key: target.work.key }),
        run: target.run as RunId,
        delta: {
          level: "warn",
          code: FILE_CHANGED_CODE,
          text: `The event file of ${target.run} changed (${detail}); ingestion for the run stopped.`,
        },
      });
      this.#append(entries, now);
    });
    if (tracked.usageDirty && (target.work !== undefined || target.storyless !== undefined)) {
      this.#usageSent(tracked, now);
    }
    this.#hooks.onFileChanged?.({ run: target.run, agent: target.agent, path, detail });
  }

  // ---- reads ---------------------------------------------------------------------------------

  #cursor(target: IngestTarget): CursorRow {
    const row = this.#office.get<CursorRow>(
      `select path, device, inode, read_offset, last_line_hash, last_line_bytes, parse_state,
         first_line_t, last_line_t, output_emitted_to, ended_at, changed_at, drift_lines
       from ingest_cursors
       where office_id = $office_id and run_id = $run and agent_id = $agent
         and source_kind = $kind`,
      { run: target.run, agent: target.agent, kind: SOURCE },
    );
    if (row === null) throw new Error(`${target.run} agent ${target.agent} has no cursor.`);
    return row;
  }

  #processedOffset(target: IngestTarget): number {
    return (
      this.#office.get<{ processed_offset: number }>(
        `select processed_offset from worker_hosts
         where office_id = $office_id and run_id = $run and agent_id = $agent`,
        { run: target.run, agent: target.agent },
      )?.processed_offset ?? 0
    );
  }

  #recordIdentity(target: IngestTarget, identity: FileIdentity): void {
    this.#office.immediate(() =>
      this.#office.run(
        `update ingest_cursors set device = $device, inode = $inode
         where office_id = $office_id and run_id = $run and agent_id = $agent
           and source_kind = $kind and device is null`,
        {
          device: identity.device,
          inode: identity.inode,
          run: target.run,
          agent: target.agent,
          kind: SOURCE,
        },
      ),
    );
  }

  /** The run's unreadable stream lines over all its agents (DIPO-315). */
  #runDriftLines(run: string): number {
    return (
      this.#office.get<{ lines: number }>(
        `select coalesce(sum(drift_lines), 0) as lines from ingest_cursors
         where office_id = $office_id and run_id = $run`,
        { run },
      )?.lines ?? 0
    );
  }

  /**
   * Inside the pass transaction: the `engine.notice` of a worker newer than its adapter was
   * checked with, once per office and version (DIPO-315); none when it was shown already.
   */
  #newerVersion(
    target: IngestTarget,
    event: Extract<WorkerEvent, { t: "newerVersion" }>,
    at: number,
  ): NewEntry[] {
    const first = this.#office.run(
      `insert into once_notices (office_id, code, shown_at)
       values ($office_id, $code, $at) on conflict do nothing`,
      { code: `${NEWER_VERSION_CODE}:${event.worker}:${event.version}`, at },
    );
    if (first.changes === 0) return [];
    return [
      {
        type: "engine.notice",
        ...(target.work === undefined ? {} : { key: target.work.key }),
        run: target.run as RunId,
        delta: {
          level: "warn",
          code: NEWER_VERSION_CODE,
          text: `${target.run} started on ${event.worker} ${event.version}, newer than ${event.checked}, the newest version dipo's recordings and box image were checked with. Its stream may have changed: a run whose stream dipo cannot read parks with cause stream-drift. dipo shows this once per version.`,
        },
      },
    ];
  }

  #agentModel(target: IngestTarget): string {
    return (
      this.#office.get<{ model: string }>(
        "select model from agents where office_id = $office_id and agent_id = $agent",
        { agent: target.agent },
      )?.model ?? target.model
    );
  }

  #hasTotals(target: IngestTarget): boolean {
    return (
      this.#office.get(
        `select 1 as found from usage_totals
         where office_id = $office_id and run_id = $run and agent_id = $agent`,
        { run: target.run, agent: target.agent },
      ) !== null
    );
  }

  #outputEnd(run: string): number {
    return (
      this.#office.get<{ end: number | null }>(
        `select max(to_offset) as end from output_chunks
         where office_id = $office_id and run_id = $run and source = 'worker'`,
        { run },
      )?.end ?? 0
    );
  }

  #emittedTo(target: IngestTarget): number {
    return (
      this.#office.get<{ output_emitted_to: number }>(
        `select output_emitted_to from ingest_cursors
         where office_id = $office_id and run_id = $run and agent_id = $agent
           and source_kind = $kind`,
        { run: target.run, agent: target.agent, kind: SOURCE },
      )?.output_emitted_to ?? 0
    );
  }
}
